package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Manages the Fire Potion's "Inferno Rage" active ability.
 * Pure aura effect - no blocks are placed or modified. A moving circular zone
 * around the player damages + ignites any player/mob standing inside it,
 * visualized with particles only.
 */
public class FireAuraManager {

    private final PotionSMP plugin;
    private final Map<UUID, Integer> activeTasks = new HashMap<>();

    public FireAuraManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public void activateInfernoAura(Player player, int durationTicks, int radius) {
        UUID uid = player.getUniqueId();
        double dps = plugin.getConfig().getDouble("potions.fire.damage-per-second", 2.0);

        Integer existing = activeTasks.remove(uid);
        if (existing != null) plugin.getServer().getScheduler().cancelTask(existing);

        BukkitRunnable auraTask = new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks >= durationTicks || !player.isOnline()) {
                    activeTasks.remove(uid);
                    cancel();
                    return;
                }

                Location center = player.getLocation();

                if (ticks % 20 == 0) {
                    for (Entity e : center.getWorld().getNearbyEntities(center, radius, 2.5, radius)) {
                        if (e instanceof LivingEntity le && !e.getUniqueId().equals(uid)) {
                            le.damage(dps, player);
                            le.setFireTicks(40);
                        }
                    }
                }

                if (ticks % 2 == 0) {
                    drawSectorRing(center);
                }
                center.getWorld().spawnParticle(Particle.FLAME, center.clone().add(0, 0.1, 0), 4, 0.2, 0, 0.2, 0.02);

                ticks++;
            }
        };

        int taskId = auraTask.runTaskTimer(plugin, 0L, 1L).getTaskId();
        activeTasks.put(uid, taskId);
    }

    /** Fixed visual radius for the sector ring, per spec: diameter 20 / radius 10, independent of the gameplay damage radius. */
    private static final double AURA_VISUAL_RADIUS = 10.0;

    /**
     * Draws a 20-block-diameter circle centered exactly on the player,
     * divided into 4 equal 90° sectors (0-90, 90-180, 180-270, 270-360).
     * The outer ring communicates the circle; 4 radial spokes at the sector
     * boundary angles (0°, 90°, 180°, 270°) communicate the 4-way division.
     */
    private void drawSectorRing(Location center) {
        // Outer ring
        int ringPoints = 60;
        for (int i = 0; i < ringPoints; i++) {
            double angle = (2 * Math.PI * i) / ringPoints;
            double x = center.getX() + AURA_VISUAL_RADIUS * Math.cos(angle);
            double z = center.getZ() + AURA_VISUAL_RADIUS * Math.sin(angle);
            Location ringPoint = new Location(center.getWorld(), x, center.getY() + 0.1, z);
            center.getWorld().spawnParticle(Particle.FLAME, ringPoint, 1, 0, 0, 0, 0);
            if (i % 3 == 0) {
                center.getWorld().spawnParticle(Particle.LAVA, ringPoint, 1, 0, 0, 0, 0);
            }
        }

        // 4 radial spokes at the sector boundaries — player (center) is the
        // exact origin of each spoke, so the sectors visually pivot on the player.
        double[] sectorBoundaries = { 0, Math.PI / 2, Math.PI, 3 * Math.PI / 2 };
        int spokeSteps = 16;
        for (double angle : sectorBoundaries) {
            double dx = Math.cos(angle);
            double dz = Math.sin(angle);
            for (int s = 1; s <= spokeSteps; s++) {
                double dist = (AURA_VISUAL_RADIUS / spokeSteps) * s;
                double x = center.getX() + dx * dist;
                double z = center.getZ() + dz * dist;
                Location spokePoint = new Location(center.getWorld(), x, center.getY() + 0.1, z);
                center.getWorld().spawnParticle(Particle.SMALL_FLAME, spokePoint, 1, 0, 0, 0, 0);
            }
        }
    }

    public void cancelAura(UUID uid) {
        Integer taskId = activeTasks.remove(uid);
        if (taskId != null) plugin.getServer().getScheduler().cancelTask(taskId);
    }

    public void cancelAll() {
        for (int id : activeTasks.values()) {
            plugin.getServer().getScheduler().cancelTask(id);
        }
        activeTasks.clear();
    }
}
