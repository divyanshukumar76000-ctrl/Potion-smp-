package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * §f Feather Potion – Feather Glide
 *
 * PASSIVE ONLY:
 * - No fall damage (ever)
 * - Auto-glide when falling using REAL Elytra glide physics (via
 *   LivingEntity#setGliding — no physical Elytra item required or consumed)
 * - Feather trail particles while gliding
 * - Glide ends on landing
 *
 * ACTIVE: None
 *
 * IMPLEMENTATION NOTE (fix): the previous version manually capped downward
 * velocity every tick — a fake slow-fall, not real gliding (no aerodynamic
 * forward momentum, no elytra visuals/animation). Per Paper's own
 * LivingEntity#setGliding(boolean) javadoc: "This will work even if an
 * Elytra is not equipped, but will be reverted by the server immediately
 * after unless an event-cancelling mechanism is put in place." So real
 * gliding is turned on with setGliding(true), and the server's automatic
 * "no elytra, revert to false" toggle is intercepted via
 * EntityToggleGlideEvent and cancelled while the player should still be
 * gliding. No Elytra item is ever touched, so nothing can be damaged/broken,
 * and allowFlight/creative-flight are never touched.
 */
public class FeatherAbility implements Ability, Listener {

    private final Set<UUID> gliding = new HashSet<>();

    public void register(PotionSMP plugin) {
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public PotionType type() { return PotionType.FEATHER; }

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        startGlideLoop(plugin, player);
        player.sendMessage("§fFeather Glide passive active — no fall damage!");
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        if (gliding.remove(uid) && player.isGliding()) {
            player.setGliding(false);
        }
        plugin.getParticleManager().cancelAura(uid);
    }

    // ── Fall damage cancel (unchanged) ──────────────────────────────────
    @EventHandler(priority = EventPriority.HIGH)
    public void onFallDamage(EntityDamageEvent e) {
        if (e.getCause() != EntityDamageEvent.DamageCause.FALL) return;
        if (!(e.getEntity() instanceof Player p)) return;
        if (PotionSMP.getInstance().getSlotManager()
                .hasEquipped(p.getUniqueId(), PotionType.FEATHER)) {
            e.setCancelled(true);
        }
    }

    // ── Keep real gliding alive without a physical Elytra ───────────────
    @EventHandler
    public void onToggleGlide(EntityToggleGlideEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        UUID uid = p.getUniqueId();
        if (!PotionSMP.getInstance().getSlotManager().hasEquipped(uid, PotionType.FEATHER)) return;

        if (!e.isGliding()) {
            // Server auto-reverting gliding to false because no Elytra is
            // equipped. If the player is still legitimately airborne and our
            // loop hasn't told them to land yet, keep gliding active.
            if (gliding.contains(uid) && !p.isOnGround()) {
                e.setCancelled(true);
            } else {
                gliding.remove(uid);
            }
        }
    }

    // ── Glide loop: detects fall state, starts/stops real gliding ──────────
    private void startGlideLoop(PotionSMP plugin, Player player) {
        new BukkitRunnable() {
            @Override
            public void run() {
                UUID uid = player.getUniqueId();
                if (!player.isOnline() ||
                    !plugin.getSlotManager().hasEquipped(uid, PotionType.FEATHER)) {
                    if (gliding.remove(uid) && player.isGliding()) player.setGliding(false);
                    cancel(); return;
                }

                Vector vel = player.getVelocity();

                // Falling (negative Y)
                if (vel.getY() < -0.1 && !player.isOnGround()) {
                    if (gliding.add(uid) && !player.isGliding()) {
                        // Real Elytra glide physics take over from here —
                        // aerodynamic descent + forward momentum, driven by
                        // the vanilla client the same way an actual Elytra is.
                        player.setGliding(true);
                    }

                    // Feather trail (unchanged aesthetic)
                    Location loc = player.getLocation().add(0, 0.2, 0);
                    loc.getWorld().spawnParticle(Particle.CLOUD,       loc, 2, 0.2,0.1,0.2, 0.02);
                    loc.getWorld().spawnParticle(Particle.END_ROD,     loc, 1, 0.2,0.1,0.2, 0.01);

                } else if (player.isOnGround()) {
                    if (gliding.remove(uid)) {
                        if (player.isGliding()) player.setGliding(false);

                        // Landing puff (unchanged aesthetic)
                        Location loc = player.getLocation();
                        loc.getWorld().spawnParticle(Particle.CLOUD, loc, 8, 0.4,0.1,0.4, 0.05);
                        loc.getWorld().playSound(loc, Sound.BLOCK_WOOL_STEP, 0.8f, 1.2f);
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ── Active: none ──────────────────────────────────────────────────────
    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        player.sendActionBar(net.kyori.adventure.text.Component.text(
            "§fFeather Potion has no active ability — it's fully passive!"));
        return ActivationResult.SUCCESS;
    }
}
