# PotionSMP — Fix Notes (this pass)

## What I could actually fix (source code present)

### 1. Paper 1.21.11 compatibility
- `pom.xml`: `paper-api` bumped `1.21.1-R0.1-SNAPSHOT` → `1.21.11-R0.1-SNAPSHOT`
  (verified this artifact exists on repo.papermc.io).
- `plugin.yml`: `api-version: '1.21'` — left as-is. This field is a
  major.minor group, not a patch pin, so it already covers 1.21.11. No
  change needed.
- Java target already `21` in `pom.xml` — no change needed.
- Scanned every Particle/Sound/PotionEffectType/DamageCause/Attribute usage
  in the codebase against the live Paper 1.21.x javadocs — all valid, no
  removed/renamed API calls found.

### 2. /swap not refreshing HUD immediately
`HudManager` already had a `sendOnce(Player)` method for exactly this purpose,
but nothing was calling it. Added `plugin.getHudManager().sendOnce(player)`
right after the slot change in:
- `SwapCommand.java` (standalone `/swap`)
- `PotionCommand.java` (`/potionsmp swap` subcommand)
- `DrinkListener.java` (right after a potion is equipped/replaced — HUD was
  previously waiting up to 10 ticks / 0.5s for the periodic refresh)

### 3. HUD glyph architecture — reviewed, no code change needed
Traced `HudManager.buildSlot()`: for a given slot it already returns **one**
character — either the empty-background glyph (`\uE901`) or the potion's own
icon glyph (`\uE001`–`\uE00D` in the existing map) — never both stacked
together. So on the Java/ActionBar side, the "one complete glyph = one
complete slot visual" architecture you described is already how this code
works; it isn't doing an overlay of two glyphs at the software level.

## What I could NOT fix — resource pack not provided

The actual visual glyphs (`assets/minecraft/font/default.json`, the
`potionsmp:` texture/sprite sheet, `empty.png`, per-potion icon PNGs) are
**not part of this zip** and were never uploaded to me. Whether the *visual
result* still looks like an "overlay hack" depends entirely on those PNGs and
how `default.json` positions them (ascent/height/advance) — that's outside
this source tree and I can't inspect or edit it without the files.

Also not provided, so not inspected: `InfuseSMP-2.4.3.jar` and `InfusePack`
(the reference system you wanted the glyph architecture modeled on), and the
1536×864 HUD screenshot with the slot coordinates.

**To finish the HUD rework properly, please upload:**
1. Current PotionSMP resource pack (font/default.json + textures)
2. `InfuseSMP-2.4.3.jar` + InfusePack, if you still want it as a reference
3. The HUD screenshot

Once I have the actual glyph assets I can build individual complete-slot PNGs
(box+icon baked into one image), regenerate `default.json` with correct
ascent/height for a 22×22 render size, and match the E-code IDs already used
in `HudManager.java` (I did **not** renumber them to E000–E00C, per your
instruction to preserve the existing mapping).

## Preserved, unchanged
- All 12 potion abilities, cooldowns, passives
- SlotManager's existing slot-fill/replace logic
- All commands, listeners, permissions, config structure
- "SHIELD" spelling kept internally in Java/config exactly as before

## Validation status
- [x] `pom.xml` targets Paper 1.21.11 / Java 21
- [x] `/swap` and `/potionsmp swap` and drinking all trigger instant HUD update
- [x] Existing abilities/slot logic untouched
- [ ] Cannot confirm actual compile (`mvn package`) — no Maven/network in this
      sandbox; do a `mvn clean package` on your machine
- [ ] HUD glyph-per-slot resource pack rework — blocked on missing assets above

---

## Update — resource pack now provided, HUD glyph fix complete

You uploaded the actual `PotionSMP-ResourcePack.zip`. Findings:

- Every potion icon PNG already bakes in its own complete frame/border — no
  overlay/negative-space trick was ever needed. The previous resource-pack
  pass (see the pack's own old NOTES.md) had added exactly the overlay hack
  you said not to use, with mismatched glyph IDs on top of that.
- Rebuilt `default.json` in the resource pack with correct one-glyph-per-slot
  mapping, matched exactly to this project's `HudManager.java` IDs.
- Generated 12 new `*_dark.png` cooldown-state images (real composited art,
  not a color-tint hack).
- **`HudManager.java` updated**: removed the `NamedTextColor` tint that was
  being applied on top of each icon glyph — with real baked-in art colors,
  that tint would have distorted every icon. IconInfo record simplified
  (dropped the unused `color` field).

See `PotionSMP-ResourcePack_FIXED.zip` (delivered alongside this) for the
resource pack itself.

### Still to verify in-game
- `ascent: 18` / `height: 22` on the font glyphs — positioning is a rendering
  choice I can't screenshot-verify from here. Check against your reference
  screenshot and nudge `ascent` on all 16 bitmap providers together if needed.
- Full `mvn clean package` compile (still no Maven/network in this sandbox).
