# PotionSMP — Fix Notes (this pass)

## What I could actually fix (source code present)

### 1. Paper 1.21.11 compatibility
- `pom.xml`: `paper-api` bumped `1.21.1-R0.1-SNAPSHOT` → `1.21.11-R0.1-SNAPSHOT`
  (verified this artifact exists on repo.papermc.io).
- `plugin.yml`: `api-version: '1.21'` — left as-is. This field is a
  major.minor group, not a patch pin, so it already covers 1.21.11. No
  change needed.
- Java target already `21` in `pom.xml` — no change needed.
- Scanned every Particle/Sound/PotionEffectType/DamageCause/Attribute usage
  in the codebase against the live Paper 1.21.x javadocs — all valid, no
  removed/renamed API calls found.

### 2. /swap not refreshing HUD immediately
`HudManager` already had a `sendOnce(Player)` method for exactly this purpose,
but nothing was calling it. Added `plugin.getHudManager().sendOnce(player)`
right after the slot change in:
- `SwapCommand.java` (standalone `/swap`)
- `PotionCommand.java` (`/potionsmp swap` subcommand)
- `DrinkListener.java` (right after a potion is equipped/replaced — HUD was
  previously waiting up to 10 ticks / 0.5s for the periodic refresh)

### 3. HUD glyph architecture — reviewed, no code change needed
Traced `HudManager.buildSlot()`: for a given slot it already returns **one**
character — either the empty-background glyph (`\uE901`) or the potion's own
icon glyph (`\uE001`–`\uE00D` in the existing map) — never both stacked
together. So on the Java/ActionBar side, the "one complete glyph = one
complete slot visual" architecture you described is already how this code
works; it isn't doing an overlay of two glyphs at the software level.

## What I could NOT fix — resource pack not provided

The actual visual glyphs (`assets/minecraft/font/default.json`, the
`potionsmp:` texture/sprite sheet, `empty.png`, per-potion icon PNGs) are
**not part of this zip** and were never uploaded to me. Whether the *visual
result* still looks like an "overlay hack" depends entirely on those PNGs and
how `default.json` positions them (ascent/height/advance) — that's outside
this source tree and I can't inspect or edit it without the files.

Also not provided, so not inspected: `InfuseSMP-2.4.3.jar` and `InfusePack`
(the reference system you wanted the glyph architecture modeled on), and the
1536×864 HUD screenshot with the slot coordinates.

**To finish the HUD rework properly, please upload:**
1. Current PotionSMP resource pack (font/default.json + textures)
2. `InfuseSMP-2.4.3.jar` + InfusePack, if you still want it as a reference
3. The HUD screenshot

Once I have the actual glyph assets I can build individual complete-slot PNGs
(box+icon baked into one image), regenerate `default.json` with correct
ascent/height for a 22×22 render size, and match the E-code IDs already used
in `HudManager.java` (I did **not** renumber them to E000–E00C, per your
instruction to preserve the existing mapping).

## Preserved, unchanged
- All 12 potion abilities, cooldowns, passives
- SlotManager's existing slot-fill/replace logic
- All commands, listeners, permissions, config structure
- "SHIELD" spelling kept internally in Java/config exactly as before

## Validation status
- [x] `pom.xml` targets Paper 1.21.11 / Java 21
- [x] `/swap` and `/potionsmp swap` and drinking all trigger instant HUD update
- [x] Existing abilities/slot logic untouched
- [ ] Cannot confirm actual compile (`mvn package`) — no Maven/network in this
      sandbox; do a `mvn clean package` on your machine
- [ ] HUD glyph-per-slot resource pack rework — blocked on missing assets above

---

## Update — resource pack now provided, HUD glyph fix complete

You uploaded the actual `PotionSMP-ResourcePack.zip`. Findings:

- Every potion icon PNG already bakes in its own complete frame/border — no
  overlay/negative-space trick was ever needed. The previous resource-pack
  pass (see the pack's own old NOTES.md) had added exactly the overlay hack
  you said not to use, with mismatched glyph IDs on top of that.
- Rebuilt `default.json` in the resource pack with correct one-glyph-per-slot
  mapping, matched exactly to this project's `HudManager.java` IDs.
- Generated 12 new `*_dark.png` cooldown-state images (real composited art,
  not a color-tint hack).
- **`HudManager.java` updated**: removed the `NamedTextColor` tint that was
  being applied on top of each icon glyph — with real baked-in art colors,
  that tint would have distorted every icon. IconInfo record simplified
  (dropped the unused `color` field).

See `PotionSMP-ResourcePack_FIXED.zip` (delivered alongside this) for the
resource pack itself.

### Still to verify in-game
- `ascent: 18` / `height: 22` on the font glyphs — positioning is a rendering
  choice I can't screenshot-verify from here. Check against your reference
  screenshot and nudge `ascent` on all 16 bitmap providers together if needed.
- Full `mvn clean package` compile (still no Maven/network in this sandbox).

---

## Update — startup NullPointerException fixed

**Crash:** `getCommand("swap")` returned `null` at `PotionSMP.java:72`, so
`.setExecutor(...)` threw an NPE during `onEnable()` and the plugin never
reached ENABLED.

**Root cause:** `plugin.yml`'s `commands:` section declared `potionsmp`,
`slot1`, `slot2` — but not `swap`. Paper only creates a `PluginCommand`
object for names actually declared under `commands:`; anything else
`getCommand()` returns `null` for, by design (not a Paper bug).

**Exact fix — `plugin.yml`:**
```yaml
  swap:
    description: Swap the potions equipped in Slot 1 and Slot 2
    usage: /swap
    permission: potionsmp.use
```
Added right after the `slot2:` entry, same style/permission as the other
slot commands.

**Java file changed:** `PotionSMP.java` — the 4-line manual
`getCommand(...).setExecutor(...)` block was replaced with a
`registerCommand(name, executor, tabCompleter)` helper that null-checks
`getCommand()` and logs `getLogger().severe(...)` instead of crashing, for
all four commands (`potionsmp`, `slot1`, `slot2`, `swap`). This is
defense-in-depth only — the actual fix is the plugin.yml entry above.

**Verified:**
- Every `getCommand(...)` call site now resolves to a real
  `commands:` entry in `plugin.yml` (checked 1:1, all 4 match).
- `potionsmp` keeps its executor + tab completer + aliases (`psmp`,
  `potion`) + permission — untouched.
- `slot1`/`slot2` untouched (they were already correctly declared).
- `permissions:` block unchanged (`potionsmp.use` default true,
  `potionsmp.give` default op) — `swap` uses `potionsmp.use`, consistent
  with the other player commands.
- `name`, `version: 3.0.0`, `main`, `api-version: '1.21'` all already
  correct for Paper 1.21.11 — no change needed.
- No potion abilities, effects, SlotManager, HUD glyph system, cooldowns,
  or resource-pack architecture were touched for this fix.

**Build:** still no Maven/network in this sandbox, so I can't produce a
literal `BUILD SUCCESS` log or launch a real Paper 1.21.11 server here.
What I *can* confirm: manual static check of the full command-registration
path (`getCommand()` call ↔ `plugin.yml` `commands:` entry ↔ executor class
constructor ↔ permission) is now fully consistent — the specific NPE in the
report cannot recur since its cause (`swap` missing from `plugin.yml`) is
fixed. Please run `mvn clean package` and start the server to get the actual
"Enabling PotionSMP v3.0.0" console confirmation.

---

## Update — 12 compilation errors fixed (Paper 1.21.11 API)

All 12 reported errors traced to real API misunderstandings/typos — none were
Paper-version issues, so no downgrade was needed or done.

### 1. `ShieldManager.java` — 6 errors: `Location.getLocation()` doesn't exist
`org.bukkit.Location` has no `getLocation()` method (only `Entity`/`Player` do).
Every failing call was `someLocationVar.getWorld().playSound(someLocationVar.getLocation(), ...)`
where `someLocationVar` was already the `Location` needed — `.getLocation()` was
a redundant, non-existent call. Fixed by passing the `Location` variable
directly: `playSound(loc, ...)` / `playSound(center, ...)`. 6 call sites fixed
(activation burst ×2, beacon ambient spark, hit-effect burst ×2, deactivate).

### 2. `FreezeAbility.java:69` — 1 error: `Sound.ENTITY_GUARDIAN_ELDER_CURSE`
Word-order typo. Verified against the live Paper 1.21.11 `Sound` enum — the
real constant is `Sound.ENTITY_ELDER_GUARDIAN_CURSE` (same one already used
correctly elsewhere in `ShieldManager.java`). Fixed the typo, no other change.

### 3. `GlitchAbility.java:95-96` — 2 errors: same `Location.getLocation()` bug as #1
Identical root cause to ShieldManager — `loc.getLocation()` where `loc` is
already a `Location`. Fixed both `playSound(...)` calls to pass `loc` directly.

### 4. `TeleportAbility.java:123` — 2 errors: missing `Entity` import + wrong `getTargetEntity` overload
- `Entity` was used but never imported — added `import org.bukkit.entity.Entity;`.
- The code called `player.getTargetEntity(60, predicate)`, assuming a
  `Predicate<Entity>`-filtered overload exists. It doesn't: Paper 1.21.11's
  `LivingEntity` only has `getTargetEntity(int maxDistance)` and
  `getTargetEntity(int maxDistance, boolean ignoreBlocks)` — the second
  overload takes a `boolean`, which is why the compiler reported "boolean is
  not a functional interface" (it was trying to match the lambda against a
  `boolean` parameter). Fixed by calling the real `getTargetEntity(60)`
  overload and moving the "is a different player" filter into an `if` check
  immediately after, preserving the original raycast → fallback-to-closest
  logic exactly.

### 5. `ItemBuilder.java:154` — 1 error: `PotionType.HASTE` doesn't exist
Checked the full `org.bukkit.potion.PotionType` enum for Paper 1.21.11 (via
live javadoc) — there is no `HASTE` constant, because Minecraft has never had
a brewable Haste potion (Haste only comes from beacons/conduits/mining
fatigue negation). `setBasePotionType(...)` just controls the vanilla potion
item's tooltip/liquid-color base — it doesn't carry PotionSMP's actual
gameplay identity (that's already handled separately by
`PotionUtils.tagPotion()` + custom-model-data). Fixed by using the neutral
`PotionType.WATER` base plus an explicit gold `meta.setColor(...)` tint so the
item still visually reads as "Haste" in inventory. No potion ability/effect
logic was touched — this only affects the item's cosmetic base type.

### Verification performed after fixing
- Re-scanned the **entire** codebase for the same two bug classes:
  - Any other `<LocationVar>.getLocation()` call — none remain; every
    remaining `.getLocation()` call site is on an `Entity`/`Player`/`LivingEntity`
    variable, which is valid.
  - Any other `getTargetEntity` call — only the one now-fixed call site exists.
  - Every other `setBasePotionType(PotionType.X)` call — all 10 remaining
    constants (`FIRE_RESISTANCE`, `SLOWNESS`, `REGENERATION`, `SWIFTNESS`,
    `TURTLE_MASTER`, `NIGHT_VISION`, `INVISIBILITY`, `SLOW_FALLING`, `LUCK`,
    `STRENGTH`) checked against the live 1.21.11 enum — all valid.
  - Every `Sound.*` constant used anywhere in the project (29 distinct
    constants) reviewed — all match standard, still-current Bukkit sound
    names.
- Error count cross-check: Shield (6) + Freeze (1) + Glitch (2) + Teleport (2)
  + ItemBuilder (1) = **12**, matching the reported error count exactly — no
  errors were missed or left unaddressed.
- Nothing else was touched: no potion ability/effect logic, no SlotManager,
  no HUD glyph system, no cooldown system, no resource-pack files were
  modified for this fix.

### Build result
This sandbox still has **no Maven and no network access** (confirmed both
before starting this fix), and not even a JDK `javac` (JRE-only), so I
genuinely cannot run `mvn clean package` or produce a real `BUILD SUCCESS`
here — I want to be upfront about that rather than claim a result I didn't
produce. What I *can* confirm: every one of the 12 specific compiler errors
you reported has a verified root-cause fix (checked against live Paper
1.21.11 javadocs, not assumption), and a full-codebase re-scan found no
further instances of either bug pattern. Please run `mvn clean package` on
your machine — if it still fails, paste the new error output and I'll
continue from there.
