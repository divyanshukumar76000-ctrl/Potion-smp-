# PotionSMP — Fix Notes (this pass)

## What I could actually fix (source code present)

### 1. Paper 1.21.11 compatibility
- `pom.xml`: `paper-api` bumped `1.21.1-R0.1-SNAPSHOT` → `1.21.11-R0.1-SNAPSHOT`
  (verified this artifact exists on repo.papermc.io).
- `plugin.yml`: `api-version: '1.21'` — left as-is. This field is a
  major.minor group, not a patch pin, so it already covers 1.21.11. No
  change needed.
- Java target already `21` in `pom.xml` — no change needed.
- Scanned every Particle/Sound/PotionEffectType/DamageCause/Attribute usage
  in the codebase against the live Paper 1.21.x javadocs — all valid, no
  removed/renamed API calls found.

### 2. /swap not refreshing HUD immediately
`HudManager` already had a `sendOnce(Player)` method for exactly this purpose,
but nothing was calling it. Added `plugin.getHudManager().sendOnce(player)`
right after the slot change in:
- `SwapCommand.java` (standalone `/swap`)
- `PotionCommand.java` (`/potionsmp swap` subcommand)
- `DrinkListener.java` (right after a potion is equipped/replaced — HUD was
  previously waiting up to 10 ticks / 0.5s for the periodic refresh)

### 3. HUD glyph architecture — reviewed, no code change needed
Traced `HudManager.buildSlot()`: for a given slot it already returns **one**
character — either the empty-background glyph (`\uE901`) or the potion's own
icon glyph (`\uE001`–`\uE00D` in the existing map) — never both stacked
together. So on the Java/ActionBar side, the "one complete glyph = one
complete slot visual" architecture you described is already how this code
works; it isn't doing an overlay of two glyphs at the software level.

## What I could NOT fix — resource pack not provided

The actual visual glyphs (`assets/minecraft/font/default.json`, the
`potionsmp:` texture/sprite sheet, `empty.png`, per-potion icon PNGs) are
**not part of this zip** and were never uploaded to me. Whether the *visual
result* still looks like an "overlay hack" depends entirely on those PNGs and
how `default.json` positions them (ascent/height/advance) — that's outside
this source tree and I can't inspect or edit it without the files.

Also not provided, so not inspected: `InfuseSMP-2.4.3.jar` and `InfusePack`
(the reference system you wanted the glyph architecture modeled on), and the
1536×864 HUD screenshot with the slot coordinates.

**To finish the HUD rework properly, please upload:**
1. Current PotionSMP resource pack (font/default.json + textures)
2. `InfuseSMP-2.4.3.jar` + InfusePack, if you still want it as a reference
3. The HUD screenshot

Once I have the actual glyph assets I can build individual complete-slot PNGs
(box+icon baked into one image), regenerate `default.json` with correct
ascent/height for a 22×22 render size, and match the E-code IDs already used
in `HudManager.java` (I did **not** renumber them to E000–E00C, per your
instruction to preserve the existing mapping).

## Preserved, unchanged
- All 12 potion abilities, cooldowns, passives
- SlotManager's existing slot-fill/replace logic
- All commands, listeners, permissions, config structure
- "SHIELD" spelling kept internally in Java/config exactly as before

## Validation status
- [x] `pom.xml` targets Paper 1.21.11 / Java 21
- [x] `/swap` and `/potionsmp swap` and drinking all trigger instant HUD update
- [x] Existing abilities/slot logic untouched
- [ ] Cannot confirm actual compile (`mvn package`) — no Maven/network in this
      sandbox; do a `mvn clean package` on your machine
- [ ] HUD glyph-per-slot resource pack rework — blocked on missing assets above

---

## Update — resource pack now provided, HUD glyph fix complete

You uploaded the actual `PotionSMP-ResourcePack.zip`. Findings:

- Every potion icon PNG already bakes in its own complete frame/border — no
  overlay/negative-space trick was ever needed. The previous resource-pack
  pass (see the pack's own old NOTES.md) had added exactly the overlay hack
  you said not to use, with mismatched glyph IDs on top of that.
- Rebuilt `default.json` in the resource pack with correct one-glyph-per-slot
  mapping, matched exactly to this project's `HudManager.java` IDs.
- Generated 12 new `*_dark.png` cooldown-state images (real composited art,
  not a color-tint hack).
- **`HudManager.java` updated**: removed the `NamedTextColor` tint that was
  being applied on top of each icon glyph — with real baked-in art colors,
  that tint would have distorted every icon. IconInfo record simplified
  (dropped the unused `color` field).

See `PotionSMP-ResourcePack_FIXED.zip` (delivered alongside this) for the
resource pack itself.

### Still to verify in-game
- `ascent: 18` / `height: 22` on the font glyphs — positioning is a rendering
  choice I can't screenshot-verify from here. Check against your reference
  screenshot and nudge `ascent` on all 16 bitmap providers together if needed.
- Full `mvn clean package` compile (still no Maven/network in this sandbox).

---

## Update — startup NullPointerException fixed

**Crash:** `getCommand("swap")` returned `null` at `PotionSMP.java:72`, so
`.setExecutor(...)` threw an NPE during `onEnable()` and the plugin never
reached ENABLED.

**Root cause:** `plugin.yml`'s `commands:` section declared `potionsmp`,
`slot1`, `slot2` — but not `swap`. Paper only creates a `PluginCommand`
object for names actually declared under `commands:`; anything else
`getCommand()` returns `null` for, by design (not a Paper bug).

**Exact fix — `plugin.yml`:**
```yaml
  swap:
    description: Swap the potions equipped in Slot 1 and Slot 2
    usage: /swap
    permission: potionsmp.use
```
Added right after the `slot2:` entry, same style/permission as the other
slot commands.

**Java file changed:** `PotionSMP.java` — the 4-line manual
`getCommand(...).setExecutor(...)` block was replaced with a
`registerCommand(name, executor, tabCompleter)` helper that null-checks
`getCommand()` and logs `getLogger().severe(...)` instead of crashing, for
all four commands (`potionsmp`, `slot1`, `slot2`, `swap`). This is
defense-in-depth only — the actual fix is the plugin.yml entry above.

**Verified:**
- Every `getCommand(...)` call site now resolves to a real
  `commands:` entry in `plugin.yml` (checked 1:1, all 4 match).
- `potionsmp` keeps its executor + tab completer + aliases (`psmp`,
  `potion`) + permission — untouched.
- `slot1`/`slot2` untouched (they were already correctly declared).
- `permissions:` block unchanged (`potionsmp.use` default true,
  `potionsmp.give` default op) — `swap` uses `potionsmp.use`, consistent
  with the other player commands.
- `name`, `version: 3.0.0`, `main`, `api-version: '1.21'` all already
  correct for Paper 1.21.11 — no change needed.
- No potion abilities, effects, SlotManager, HUD glyph system, cooldowns,
  or resource-pack architecture were touched for this fix.

**Build:** still no Maven/network in this sandbox, so I can't produce a
literal `BUILD SUCCESS` log or launch a real Paper 1.21.11 server here.
What I *can* confirm: manual static check of the full command-registration
path (`getCommand()` call ↔ `plugin.yml` `commands:` entry ↔ executor class
constructor ↔ permission) is now fully consistent — the specific NPE in the
report cannot recur since its cause (`swap` missing from `plugin.yml`) is
fixed. Please run `mvn clean package` and start the server to get the actual
"Enabling PotionSMP v3.0.0" console confirmation.

---

## Update — 12 compilation errors fixed (Paper 1.21.11 API)

All 12 reported errors traced to real API misunderstandings/typos — none were
Paper-version issues, so no downgrade was needed or done.

### 1. `ShieldManager.java` — 6 errors: `Location.getLocation()` doesn't exist
`org.bukkit.Location` has no `getLocation()` method (only `Entity`/`Player` do).
Every failing call was `someLocationVar.getWorld().playSound(someLocationVar.getLocation(), ...)`
where `someLocationVar` was already the `Location` needed — `.getLocation()` was
a redundant, non-existent call. Fixed by passing the `Location` variable
directly: `playSound(loc, ...)` / `playSound(center, ...)`. 6 call sites fixed
(activation burst ×2, beacon ambient spark, hit-effect burst ×2, deactivate).

### 2. `FreezeAbility.java:69` — 1 error: `Sound.ENTITY_GUARDIAN_ELDER_CURSE`
Word-order typo. Verified against the live Paper 1.21.11 `Sound` enum — the
real constant is `Sound.ENTITY_ELDER_GUARDIAN_CURSE` (same one already used
correctly elsewhere in `ShieldManager.java`). Fixed the typo, no other change.

### 3. `GlitchAbility.java:95-96` — 2 errors: same `Location.getLocation()` bug as #1
Identical root cause to ShieldManager — `loc.getLocation()` where `loc` is
already a `Location`. Fixed both `playSound(...)` calls to pass `loc` directly.

### 4. `TeleportAbility.java:123` — 2 errors: missing `Entity` import + wrong `getTargetEntity` overload
- `Entity` was used but never imported — added `import org.bukkit.entity.Entity;`.
- The code called `player.getTargetEntity(60, predicate)`, assuming a
  `Predicate<Entity>`-filtered overload exists. It doesn't: Paper 1.21.11's
  `LivingEntity` only has `getTargetEntity(int maxDistance)` and
  `getTargetEntity(int maxDistance, boolean ignoreBlocks)` — the second
  overload takes a `boolean`, which is why the compiler reported "boolean is
  not a functional interface" (it was trying to match the lambda against a
  `boolean` parameter). Fixed by calling the real `getTargetEntity(60)`
  overload and moving the "is a different player" filter into an `if` check
  immediately after, preserving the original raycast → fallback-to-closest
  logic exactly.

### 5. `ItemBuilder.java:154` — 1 error: `PotionType.HASTE` doesn't exist
Checked the full `org.bukkit.potion.PotionType` enum for Paper 1.21.11 (via
live javadoc) — there is no `HASTE` constant, because Minecraft has never had
a brewable Haste potion (Haste only comes from beacons/conduits/mining
fatigue negation). `setBasePotionType(...)` just controls the vanilla potion
item's tooltip/liquid-color base — it doesn't carry PotionSMP's actual
gameplay identity (that's already handled separately by
`PotionUtils.tagPotion()` + custom-model-data). Fixed by using the neutral
`PotionType.WATER` base plus an explicit gold `meta.setColor(...)` tint so the
item still visually reads as "Haste" in inventory. No potion ability/effect
logic was touched — this only affects the item's cosmetic base type.

### Verification performed after fixing
- Re-scanned the **entire** codebase for the same two bug classes:
  - Any other `<LocationVar>.getLocation()` call — none remain; every
    remaining `.getLocation()` call site is on an `Entity`/`Player`/`LivingEntity`
    variable, which is valid.
  - Any other `getTargetEntity` call — only the one now-fixed call site exists.
  - Every other `setBasePotionType(PotionType.X)` call — all 10 remaining
    constants (`FIRE_RESISTANCE`, `SLOWNESS`, `REGENERATION`, `SWIFTNESS`,
    `TURTLE_MASTER`, `NIGHT_VISION`, `INVISIBILITY`, `SLOW_FALLING`, `LUCK`,
    `STRENGTH`) checked against the live 1.21.11 enum — all valid.
  - Every `Sound.*` constant used anywhere in the project (29 distinct
    constants) reviewed — all match standard, still-current Bukkit sound
    names.
- Error count cross-check: Shield (6) + Freeze (1) + Glitch (2) + Teleport (2)
  + ItemBuilder (1) = **12**, matching the reported error count exactly — no
  errors were missed or left unaddressed.
- Nothing else was touched: no potion ability/effect logic, no SlotManager,
  no HUD glyph system, no cooldown system, no resource-pack files were
  modified for this fix.

### Build result
This sandbox still has **no Maven and no network access** (confirmed both
before starting this fix), and not even a JDK `javac` (JRE-only), so I
genuinely cannot run `mvn clean package` or produce a real `BUILD SUCCESS`
here — I want to be upfront about that rather than claim a result I didn't
produce. What I *can* confirm: every one of the 12 specific compiler errors
you reported has a verified root-cause fix (checked against live Paper
1.21.11 javadocs, not assumption), and a full-codebase re-scan found no
further instances of either bug pattern. Please run `mvn clean package` on
your machine — if it still fails, paste the new error output and I'll
continue from there.

---

## Update — Fire / Feather / Speed / Ender / Strength mechanic fixes

Full report below. Freeze, Shield, Emerald, Haste, Regen were **not touched** —
confirmed via file hash before/after this pass on FreezeAbility.java,
ShieldManager.java, EmeraldAbility.java, RegenAbilityManager.java (identical),
and HasteAbility.java was never opened for editing. HUD, ActionBar, resource
pack, glyph mapping, and the slot system were also not touched.

### 1. Fire — 4-sector 90° circle
**File:** `FireAuraManager.java`
Replaced the plain ring (`drawRing`) with `drawSectorRing`: a fixed 10-block-
radius (20-block-diameter) circle, always centered on the player's current
tick-by-tick location, plus 4 radial spokes at 0°/90°/180°/270° that visually
divide it into the required four 90° sectors. The ring redraw is now
throttled to every 2 ticks (was every tick) for lighter particle load; the
continuous origin wisp still runs every tick. **Damage/ignition logic in
`activateInfernoAura` was not touched** — it still uses the configurable
`potions.fire.active-fire-radius` (currently 5 in config.yml) for the actual
damage zone, separate from the new fixed 10-block *visual* radius, per your
instruction not to change damage behavior. Flagging this in case you want the
config default raised to 10 to match the new visual — I didn't change it
since gameplay radius wasn't part of the request.

### 2. Feather — real Elytra glide (root cause + fix)
**File:** `FeatherAbility.java`
**Root cause:** confirmed exactly as you suspected — the old code capped
downward velocity manually every tick (`Math.max(vel.getY(), -0.15)`). That's
a fake slow-fall, not gliding: no aerodynamic forward momentum, no glide
animation, nothing Elytra-related at all.
**Fix:** uses the real API — `LivingEntity#setGliding(boolean)`. Per Paper's
own 1.21.11 javadoc, this "will work even if an Elytra is not equipped, but
will be reverted by the server immediately after unless an event-cancelling
mechanism is put in place." So: the glide loop calls `player.setGliding(true)`
when the player is genuinely falling, and a new `EntityToggleGlideEvent`
handler cancels the server's automatic revert-to-false while the player
should still be airborne — landing (or unequip) lets it turn off normally
via an explicit `setGliding(false)`. (Note: the task text referenced
`PlayerToggleGlideEvent`, which doesn't exist in Bukkit — the real event is
`org.bukkit.event.entity.EntityToggleGlideEvent`, confirmed against the live
1.21.11 javadoc.) No Elytra item is ever equipped/touched, so nothing can be
damaged; `allowFlight` and creative flight are never touched; fall-damage
cancellation (existing `EntityDamageEvent` handler) and the feather trail /
landing-puff particles are unchanged.

### 3. Speed — dash→shockwave timing (root cause + fix)
**File:** `SpeedAbility.java`
**Root cause:** `executeDash()` applied the launch velocity **once** at the
start (`player.setVelocity(dir)`), then ran a 36-tick (1.8s) timer that only
spawned trail particles and waited. Minecraft's normal ground/air friction
decays a single velocity impulse within a handful of ticks, so the player
visually stopped moving well before the 36-tick timer finished — the
shockwave (fired only when the timer ends) looked like it started late
relative to when the dash actually stopped.
**Fix:** the dash direction is still locked at activation (unchanged), but
now it's **reapplied every tick** for the full 36 ticks (only the horizontal
component — vertical velocity from gravity/jumping is preserved untouched),
so the player is genuinely still dashing right up to the moment the timer
ends and the shockwave fires — zero gap. The 1.8s duration, Speed IV,
Resistance, dash particles, cooldown, shockwave damage, and knockback are
all unchanged.

### 4. Ender — full audit findings + fixes
**Files:** `EnderDomainManager.java`, `TeleportAbility.java`
Traced the full chain (equip → passive aura → hit counter → Void Corruption →
active → Abyss Domain → debuffs/lightning/suppression → collapse). Most of
the chain is actually correctly implemented (passive hit counting via the
already-solid `HitCounterManager`, domain debuffs, lightning, ring/ground
visuals, collapse effects, and task cancellation all check out). Two real
issues found:

- **Suppression was never enforced (the actual "incomplete" bug).**
  `EnderDomainManager.isSuppressed(uuid)` was implemented and the `suppressed`
  map was correctly populated every domain tick — but **nothing in the entire
  codebase ever called `isSuppressed()`**. The documented "Suppresses
  Teleport/Shield/Regen abilities for enemies inside" behavior never
  actually did anything. I wired this up in `TeleportAbility.activate()`
  (blocks Shadow Teleport with a message while suppressed) since Teleport
  isn't on the protected list. **I did not wire this into Shield or Regen** —
  both are explicitly on your do-not-touch list this pass (rules #6 and #8),
  and enforcing suppression there would require editing `ShieldManager` /
  `ShieldAbility` and `RegenAbilityManager`. Flagging this clearly: Shield
  and Regen suppression are still no-ops. Say the word and I'll wire those
  up too in a follow-up pass.

- **Domain anchor position — verified as intended, left unchanged.**
  Confirmed `Location center = owner.getLocation().clone()` is captured once
  at `startDomain()` and never updated — the domain is a stationary zone, not
  a following aura (unlike Fire's aura, which explicitly follows the
  player). This matches "Abyss Domain" reading as a fixed ground-zone
  ability, distinct from Fire's aura by design. Per your instruction, left
  unchanged.

- **Minor cleanup-ordering tightening.** The lightning sub-task had its own
  independent `!owner.isOnline()` check that just self-cancelled without
  cleaning up its map entry or the `suppressed` map — the main domain loop's
  own offline-check would catch and clean up shortly after anyway (self-
  healing within ~1s), but I made the lightning task's offline-check call the
  same `endDomain()` cleanup path directly for deterministic behavior
  regardless of which task notices the logout first.

- **Known remaining limitation (not fixed, flagging only):** `suppressed` is
  `Map<UUID enemy, UUID owner>` — a single owner per enemy. If two different
  Ender players' domains ever overlap on the same target, the second domain
  overwrites the first's suppression record, and if the second domain ends
  first, the target's suppression is cleared even though they're still
  standing in the first domain. This is a rare multi-caster edge case;
  fixing it properly means restructuring `suppressed` into a
  `Map<UUID, Set<UUID>>`, which is a bigger structural change than "smallest
  correct fix" for this pass, so I left it and am flagging it instead.

### 5. Strength — counting root cause + fix
**Files:** `StrengthAbility.java` (no changes to `CombatListener.java` needed)
**Audit finding:** confirmed the "two combat paths" you flagged are not
actually duplicating anything — `CombatListener` calls `ability.onHit(...)`
on the equipped ability via the `Ability` interface, but `StrengthAbility`
never overrides `onHit()`, so that call is a no-op default for Strength. The
**only** active path is Strength's own separate `EntityDamageByEntityEvent`
listener — confirmed, not duplicated.
**Actual bug:** that listener applied the 2× mob-damage and low-HP bonuses
directly on the raw event with **no protection** against Minecraft
occasionally firing `EntityDamageByEntityEvent` more than once for a single
visual swing — a documented, already-solved problem for Fire/Ender via
`HitCounterManager`'s debounce, which Strength simply wasn't using.
**Fix:** reused that same, already-tested `HitCounterManager.registerHit(...)`
debounce (no new mechanic invented) so the damage bonus is applied exactly
once per real swing. Verified via the registration order in `PotionSMP.java`
that `CombatListener`'s shield-cancel check (which cancels the event for
shielded defenders) registers *before* `StrengthAbility`'s own listener, and
both are same-priority (`HIGH`) — combined with `ignoreCancelled = true` on
Strength's handler, shielded targets are already correctly excluded from the
bonus (no change needed there). Mobs/Monster detection, crit-spark visual,
and shield-disable-on-spark logic are all unchanged.

### Build result
Same sandbox constraints as before — no Maven, no network, no `javac`
available here, confirmed again before starting. I can't produce a literal
`BUILD SUCCESS`. What I did do: manually reviewed every edited file for
brace balance and re-scanned for the specific bug classes already found and
fixed in the previous compilation-error pass (stray `.getLocation()` calls,
invalid enum names) — none reappeared in this session's edits. Please run
`mvn clean package` — if anything fails, paste the output and I'll continue.

### Remaining in-game testing needed
- Fire: visually confirm the 4-sector spoke pattern reads clearly at 10-block
  radius and doesn't feel too particle-heavy even at every-2-ticks.
- Feather: confirm gliding actually engages/holds properly across various
  fall scenarios (short hops, long falls, near terrain) — `setGliding()`
  interacting with terrain collision hasn't been in-game verified.
- Speed: confirm the sustained-velocity dash doesn't feel "sticky" or fight
  player-attempted steering/jumping during the dash window.
- Ender: confirm Teleport-while-suppressed messaging feels right in practice;
  decide whether Shield/Regen suppression should be wired up next.
- Strength: confirm no legitimate hits are now being dropped by the debounce
  window (2 ticks) under real network-latency conditions.
