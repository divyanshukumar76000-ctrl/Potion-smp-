package com.tempestcore.ability;

import com.tempestcore.TempestCorePlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

public class AbilityManager {

    private static final long COOLDOWN_MS = 30_000L; // 30 seconds
    private static final int FREEZE_RADIUS   = 10;   // blocks around caster
    private static final int IMPACT_RADIUS   = 8;    // blocks on landing
    private static final double IMPACT_DAMAGE = 12.0; // half-hearts × 2
    private static final double ASCENT_VELOCITY = 1.6;

    private final TempestCorePlugin plugin;
    private final NamespacedKey abilityKey;

    // State tracking
    private final Set<UUID>                              activeAbility;
    private final Map<UUID, Map<UUID, Location>>        frozenEntities;   // caster → (entity → saved location)
    private final Set<UUID>                              pearlLockActive;
    private final Map<UUID, List<BukkitTask>>           taskRegistry;
    private final Map<UUID, Long>                        cooldowns;
    private final Map<UUID, boolean[]>                   snapshotMap;      // [hasStorm, isThundering]
    private final Set<UUID>                              impactDamageTargets;

    public AbilityManager(TempestCorePlugin plugin, NamespacedKey abilityKey) {
        this.plugin             = plugin;
        this.abilityKey         = abilityKey;
        this.activeAbility      = new HashSet<>();
        this.frozenEntities     = new HashMap<>();
        this.pearlLockActive    = new HashSet<>();
        this.taskRegistry       = new HashMap<>();
        this.cooldowns          = new HashMap<>();
        this.snapshotMap        = new HashMap<>();
        this.impactDamageTargets = new HashSet<>();
    }

    // ── Persistence helpers ───────────────────────────────────────────────────

    public boolean hasAbsorbedTempest(Player player) {
        PersistentDataContainer pdc = player.getPersistentDataContainer();
        String state = pdc.getOrDefault(new NamespacedKey(plugin, "arcane_slot_1"),
                PersistentDataType.STRING, "NONE");
        return "TEMPEST".equals(state);
    }

    public void absorbTempestCore(Player player) {
        PersistentDataContainer pdc = player.getPersistentDataContainer();
        pdc.set(new NamespacedKey(plugin, "arcane_slot_1"),
                PersistentDataType.STRING, "TEMPEST");
    }

    // ── Item factory ──────────────────────────────────────────────────────────

    public ItemStack createAbilityItem() {
        ItemStack item = new ItemStack(Material.NETHER_STAR);
        ItemMeta meta = item.getItemMeta();

        meta.displayName(Component.text("⚡ Tempest Core", NamedTextColor.YELLOW)
                .decoration(TextDecoration.ITALIC, false)
                .decorate(TextDecoration.BOLD));

        meta.lore(List.of(
                Component.text("Right-Click", NamedTextColor.AQUA)
                        .decoration(TextDecoration.ITALIC, false)
                        .append(Component.text(" to absorb the storm's soul", NamedTextColor.GRAY)),
                Component.text("Shift + Right-Click", NamedTextColor.YELLOW)
                        .decoration(TextDecoration.ITALIC, false)
                        .append(Component.text(" to unleash Tempest", NamedTextColor.GRAY)),
                Component.empty(),
                Component.text("Cooldown: 30s", NamedTextColor.DARK_GRAY)
                        .decoration(TextDecoration.ITALIC, false)
        ));

        meta.addEnchant(Enchantment.UNBREAKING, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

        meta.getPersistentDataContainer()
                .set(abilityKey, PersistentDataType.STRING, "tempest_core");

        item.setItemMeta(meta);
        return item;
    }

    // ── Cooldown check ────────────────────────────────────────────────────────

    public boolean isOnCooldown(Player player) {
        UUID uuid = player.getUniqueId();
        if (!cooldowns.containsKey(uuid)) return false;
        long elapsed = System.currentTimeMillis() - cooldowns.get(uuid);
        return elapsed < COOLDOWN_MS;
    }

    public long getRemainingCooldown(Player player) {
        UUID uuid = player.getUniqueId();
        if (!cooldowns.containsKey(uuid)) return 0;
        long elapsed = System.currentTimeMillis() - cooldowns.get(uuid);
        return Math.max(0, (COOLDOWN_MS - elapsed) / 1000);
    }

    // ── Main trigger ──────────────────────────────────────────────────────────

    public void triggerAbility(Player caster) {
        if (!hasAbsorbedTempest(caster)) {
            caster.sendMessage(Component.text("❌ Pehle Core ko absorb karo!", NamedTextColor.RED));
            return;
        }

        if (activeAbility.contains(caster.getUniqueId())) {
            caster.sendMessage(Component.text("⚡ Ability already active!", NamedTextColor.YELLOW));
            return;
        }

        if (isOnCooldown(caster)) {
            long secs = getRemainingCooldown(caster);
            caster.sendMessage(Component.text("⏳ Cooldown: " + secs + "s remaining", NamedTextColor.GOLD));
            return;
        }

        UUID uuid = caster.getUniqueId();
        World world = caster.getWorld();

        // Snapshot weather so we can restore it
        snapshotMap.put(uuid, new boolean[]{world.hasStorm(), world.isThundering()});
        activeAbility.add(uuid);
        cooldowns.put(uuid, System.currentTimeMillis());
        taskRegistry.put(uuid, new ArrayList<>());

        phaseLockIn(caster, world);
        phaseAscent(caster);
        phaseGravityDrop(caster);
    }

    // ── Phase 1: Lock-In ──────────────────────────────────────────────────────
    // Force a thunderstorm, freeze nearby entities, visual/sound fanfare.

    private void phaseLockIn(Player caster, World world) {
        world.setStorm(true);
        world.setThundering(true);
        world.setWeatherDuration(400); // 20 seconds – covers the whole ability

        caster.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 10, 255, false, false));
        caster.playSound(caster.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0f, 0.6f);
        caster.sendMessage(Component.text("⚡ TEMPEST LOCKED IN!", NamedTextColor.YELLOW).decorate(TextDecoration.BOLD));

        // Freeze nearby living entities
        Location origin = caster.getLocation();
        Map<UUID, Location> frozenMap = new HashMap<>();
        for (Entity entity : origin.getWorld().getNearbyEntities(origin, FREEZE_RADIUS, FREEZE_RADIUS, FREEZE_RADIUS)) {
            if (entity instanceof LivingEntity living && !entity.getUniqueId().equals(caster.getUniqueId())) {
                frozenMap.put(entity.getUniqueId(), entity.getLocation().clone());
                living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 255, false, false));
                living.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 100, -10, false, false));
                // Particle cage around each frozen entity
                entity.getWorld().spawnParticle(Particle.ELECTRIC_SPARK,
                        entity.getLocation().add(0, 1, 0), 30, 0.4, 0.6, 0.4, 0.05);
            }
        }
        frozenEntities.put(caster.getUniqueId(), frozenMap);

        // Ongoing freeze ticker – keeps entities in place for 5 seconds
        BukkitTask freezeTicker = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Map.Entry<UUID, Location> entry : frozenMap.entrySet()) {
                Entity e = Bukkit.getEntity(entry.getKey());
                if (e != null && e.isValid()) {
                    e.teleport(entry.getValue());
                }
            }
        }, 2L, 2L);

        // Cancel freeze after 5 seconds (100 ticks)
        Bukkit.getScheduler().runTaskLater(plugin, freezeTicker::cancel, 100L);
        taskRegistry.get(caster.getUniqueId()).add(freezeTicker);
    }

    // ── Phase 2: Ascent ───────────────────────────────────────────────────────
    // Launch caster upward; give levitation + lightning flash.

    private void phaseAscent(Player caster) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!caster.isOnline()) return;

            caster.playSound(caster.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 1.0f, 0.5f);
            caster.getWorld().spawnParticle(Particle.CLOUD, caster.getLocation(), 40, 0.3, 0.1, 0.3, 0.15);

            // Upward velocity burst
            caster.setVelocity(new Vector(0, ASCENT_VELOCITY, 0));
            caster.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, 40, 2, false, false));
            caster.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 20, 0, false, false));

            // Spawn a lightning bolt at launch point (cosmetic – no damage)
            caster.getWorld().strikeLightningEffect(caster.getLocation());
            caster.sendMessage(Component.text("🌩 ASCENDING...", NamedTextColor.AQUA));

        }, 5L); // slight delay after lock-in fanfare
    }

    // ── Phase 3: Gravity Drop ─────────────────────────────────────────────────
    // After hang time, slam caster down; deal AoE damage; restore weather.

    private void phaseGravityDrop(Player caster) {
        // Begin drop 3 seconds (60t) after trigger
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!caster.isOnline()) return;

            // Remove levitation so gravity takes over; give Speed for the drop feel
            caster.removePotionEffect(PotionEffectType.LEVITATION);
            caster.removePotionEffect(PotionEffectType.SLOW_FALLING);
            caster.setVelocity(new Vector(0, -3.5, 0)); // slam downward

            caster.playSound(caster.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.8f, 1.4f);
            caster.sendMessage(Component.text("💥 GRAVITY DROP!", NamedTextColor.RED).decorate(TextDecoration.BOLD));

            // Mark caster so DamageListener knows we need to skip fall damage
            pearlLockActive.add(caster.getUniqueId());

            // Wait until caster lands (poll every 2 ticks up to 5 seconds)
            final int[] ticksWaited = {0};
            BukkitTask landDetector = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
                ticksWaited[0]++;
                if (!caster.isOnline()) return;

                boolean onGround = caster.isOnGround();
                boolean timeout  = ticksWaited[0] > 100; // 5-second safety

                if (onGround || timeout) {
                    onLanding(caster);
                }
            }, 5L, 2L);

            taskRegistry.get(caster.getUniqueId()).add(landDetector);

        }, 60L);
    }

    // ── Landing impact ────────────────────────────────────────────────────────

    private void onLanding(Player caster) {
        UUID uuid = caster.getUniqueId();

        // Cancel land-detector task
        List<BukkitTask> tasks = taskRegistry.getOrDefault(uuid, Collections.emptyList());
        tasks.forEach(BukkitTask::cancel);
        taskRegistry.remove(uuid);

        Location ground = caster.getLocation();
        World world = caster.getWorld();

        // Visual + sound impact
        world.spawnParticle(Particle.EXPLOSION, ground, 5, 1.5, 0.5, 1.5, 0.1);
        world.spawnParticle(Particle.ELECTRIC_SPARK, ground, 80, 3.0, 0.5, 3.0, 0.2);
        world.playSound(ground, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 0.8f);
        world.strikeLightningEffect(ground);

        // AoE damage to nearby living entities
        for (Entity entity : world.getNearbyEntities(ground, IMPACT_RADIUS, IMPACT_RADIUS, IMPACT_RADIUS)) {
            if (entity instanceof LivingEntity target && !entity.getUniqueId().equals(uuid)) {
                impactDamageTargets.add(entity.getUniqueId());
                target.damage(IMPACT_DAMAGE, caster);
                // Knock them away
                Vector knockback = entity.getLocation().toVector()
                        .subtract(ground.toVector()).normalize()
                        .multiply(1.8).setY(0.6);
                entity.setVelocity(knockback);
                impactDamageTargets.remove(entity.getUniqueId());
            }
        }

        caster.sendMessage(Component.text("✅ Tempest released! Cooldown: 30s", NamedTextColor.GREEN));

        // Cleanup
        pearlLockActive.remove(uuid);
        frozenEntities.remove(uuid);
        activeAbility.remove(uuid);

        // Restore weather
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            boolean[] snap = snapshotMap.getOrDefault(uuid, new boolean[]{false, false});
            world.setStorm(snap[0]);
            world.setThundering(snap[1]);
            snapshotMap.remove(uuid);
        }, 40L);
    }

    // ── Getters ───────────────────────────────────────────────────────────────

    public TempestCorePlugin getPlugin()               { return plugin; }
    public Set<UUID> getActiveAbility()                { return activeAbility; }
    public Set<UUID> getPearlLockActive()              { return pearlLockActive; }
    public Map<UUID, Map<UUID, Location>> getFrozenEntities() { return frozenEntities; }
    public Set<UUID> getImpactDamageTargets()          { return impactDamageTargets; }
    public NamespacedKey getAbilityKey()               { return abilityKey; }
}
