package com.tempestcore.hud;

import com.tempestcore.ability.AbilityManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class HUDRenderer extends BukkitRunnable {

    private final AbilityManager abilityManager;

    public HUDRenderer(AbilityManager abilityManager) {
        this.abilityManager = abilityManager;
    }

    @Override
    public void run() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            boolean hasTempest = abilityManager.hasAbsorbedTempest(player);
            Component hudMessage;

            if (hasTempest) {
                hudMessage = Component.text("[⚡ TEMPEST]", NamedTextColor.YELLOW)
                        .append(Component.text("   [🔒 SLOT 2]", NamedTextColor.GRAY));
            } else {
                hudMessage = Component.text("[🔒 EMPTY]", NamedTextColor.GRAY)
                        .append(Component.text("   [🔒 SLOT 2]", NamedTextColor.GRAY));
            }

            player.sendActionBar(hudMessage);
        }
    }
}