package com.tempestcore;

import com.tempestcore.ability.AbilityManager;
import com.tempestcore.commands.TempestCoreCommand;
import com.tempestcore.hud.HUDRenderer;
import com.tempestcore.listeners.*;
import org.bukkit.NamespacedKey;
import org.bukkit.plugin.java.JavaPlugin;

public class TempestCorePlugin extends JavaPlugin {

    private AbilityManager abilityManager;
    private NamespacedKey abilityKey;

    @Override
    public void onEnable() {
        this.abilityKey     = new NamespacedKey(this, "tempest_item_tag");
        this.abilityManager = new AbilityManager(this, abilityKey);

        // Register listeners
        getServer().getPluginManager().registerEvents(new PlayerInteractListener(this, abilityManager), this);
        getServer().getPluginManager().registerEvents(new PlayerMoveListener(abilityManager), this);
        getServer().getPluginManager().registerEvents(new DamageListener(abilityManager), this);
        getServer().getPluginManager().registerEvents(new TeleportListener(abilityManager), this);
        getServer().getPluginManager().registerEvents(new PlayerStateListener(abilityManager), this);

        // Register commands
        getCommand("tempestcore").setExecutor(new TempestCoreCommand(this, abilityManager));

        // Start HUD task (every 5 ticks)
        new HUDRenderer(abilityManager).runTaskTimerAsynchronously(this, 0L, 5L);

        getLogger().info("TempestCore v1.0 enabled — Storm. Ascend. Strike.");
    }

    public AbilityManager getAbilityManager() { return abilityManager; }
    public NamespacedKey  getAbilityKey()      { return abilityKey; }
}
