package com.tempestcore.listeners;

import com.tempestcore.TempestCorePlugin;
import com.tempestcore.ability.AbilityManager;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

public class PlayerInteractListener implements Listener {

    private final TempestCorePlugin plugin;
    private final AbilityManager abilityManager;

    public PlayerInteractListener(TempestCorePlugin plugin, AbilityManager abilityManager) {
        this.plugin = plugin;
        this.abilityManager = abilityManager;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = event.getItem();

        if (item == null || item.getType() == Material.AIR) return;

        PersistentDataContainer pdc = item.getItemMeta().getPersistentDataContainer();
        if (!pdc.has(plugin.getAbilityKey(), PersistentDataType.STRING)) return;

        String tag = pdc.get(plugin.getAbilityKey(), PersistentDataType.STRING);
        if (!"tempest_core".equals(tag)) return;

        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        if (player.isSneaking()) {
            // Shift + Right Click: Original ability
            if (abilityManager.hasAbsorbedTempest(player)) {
                abilityManager.triggerAbility(player);
            } else {
                player.sendMessage("❌ Pehle Core ko absorb karo!");
            }
        } else {
            // Normal Right Click: Absorption
            if (abilityManager.hasAbsorbedTempest(player)) {
                player.sendMessage("❌ Tumhari rooh me pehle se Tempest Core active hai!");
                return;
            }

            // Consume item
            if (item.getAmount() > 1) {
                item.setAmount(item.getAmount() - 1);
            } else {
                player.getInventory().setItemInMainHand(null);
            }

            abilityManager.absorbTempestCore(player);
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_BURP, 1.0f, 1.0f);
            player.sendMessage("✅ Tempest Core absorbed! HUD active.");
        }

        event.setCancelled(true);
    }
}