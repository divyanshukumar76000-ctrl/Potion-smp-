package com.tempestcore.listeners;

import com.tempestcore.ability.AbilityManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

public class PlayerMoveListener implements Listener {

    private final AbilityManager abilityManager;

    public PlayerMoveListener(AbilityManager abilityManager) {
        this.abilityManager = abilityManager;
    }

    /** Lock horizontal movement during the Lock-In phase (first ~5 ticks).
     *  We only restrict XZ movement, not Y, so the ascent still fires. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!abilityManager.getActiveAbility().contains(player.getUniqueId())) return;

        // Allow vertical movement (for ascent / drop) but block walking away
        if (event.getFrom().getBlockX() != event.getTo().getBlockX()
                || event.getFrom().getBlockZ() != event.getTo().getBlockZ()) {
            // Only cancel horizontal walk – copy Y, pitch, yaw from "to"
            var fixed = event.getFrom().clone();
            fixed.setY(event.getTo().getY());
            fixed.setPitch(event.getTo().getPitch());
            fixed.setYaw(event.getTo().getYaw());
            event.setTo(fixed);
        }
    }
}
