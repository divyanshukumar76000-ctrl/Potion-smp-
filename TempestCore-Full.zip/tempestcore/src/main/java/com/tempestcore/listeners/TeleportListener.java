package com.tempestcore.listeners;

import com.tempestcore.ability.AbilityManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerTeleportEvent;

public class TeleportListener implements Listener {

    private final AbilityManager abilityManager;

    public TeleportListener(AbilityManager abilityManager) {
        this.abilityManager = abilityManager;
    }

    /** Block ender pearls / chorus fruit while the ability is active so the
     *  caster can't escape their own gravity drop. */
    @EventHandler
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        Player player = event.getPlayer();
        if (!abilityManager.getActiveAbility().contains(player.getUniqueId())) return;

        PlayerTeleportEvent.TeleportCause cause = event.getCause();
        if (cause == PlayerTeleportEvent.TeleportCause.ENDER_PEARL
                || cause == PlayerTeleportEvent.TeleportCause.CHORUS_FRUIT) {
            event.setCancelled(true);
        }
    }
}
