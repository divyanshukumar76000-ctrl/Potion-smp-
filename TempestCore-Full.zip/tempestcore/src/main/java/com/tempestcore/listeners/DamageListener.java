package com.tempestcore.listeners;

import com.tempestcore.ability.AbilityManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

public class DamageListener implements Listener {

    private final AbilityManager abilityManager;

    public DamageListener(AbilityManager abilityManager) {
        this.abilityManager = abilityManager;
    }

    /** Cancel fall damage for the caster during the gravity drop. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (event.getCause() != EntityDamageEvent.DamageCause.FALL) return;
        if (abilityManager.getPearlLockActive().contains(player.getUniqueId())) {
            event.setCancelled(true);
        }
    }
}
