package com.tempestcore.listeners;

import com.tempestcore.ability.AbilityManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerStateListener implements Listener {

    private final AbilityManager abilityManager;

    public PlayerStateListener(AbilityManager abilityManager) {
        this.abilityManager = abilityManager;
    }

    /** Clean up all state when a player disconnects mid-ability,
     *  so their UUID doesn't get stuck in the active/frozen sets. */
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        var uuid = event.getPlayer().getUniqueId();
        abilityManager.getActiveAbility().remove(uuid);
        abilityManager.getPearlLockActive().remove(uuid);
        abilityManager.getFrozenEntities().remove(uuid);
    }
}
