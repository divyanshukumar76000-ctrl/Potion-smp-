package com.tempestcore.commands;

import com.tempestcore.TempestCorePlugin;
import com.tempestcore.ability.AbilityManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TempestCoreCommand implements CommandExecutor {

    private final TempestCorePlugin plugin;
    private final AbilityManager abilityManager;

    public TempestCoreCommand(TempestCorePlugin plugin, AbilityManager abilityManager) {
        this.plugin = plugin;
        this.abilityManager = abilityManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) return false;

        if (args.length > 0 && args[0].equalsIgnoreCase("give")) {
            if (player.hasPermission("tempestcore.admin")) {
                player.getInventory().addItem(abilityManager.createAbilityItem());
                player.sendMessage("✅ Tempest Core item given!");
            }
            return true;
        }
        return false;
    }
}