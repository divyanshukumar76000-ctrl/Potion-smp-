package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Manages the Fire Potion's "Inferno Rage" active ability.
 * Pure aura effect - no blocks are placed or modified. A moving circular zone
 * around the player damages + ignites any player/mob standing inside it,
 * visualized with particles only.
 */
public class FireAuraManager {

    private final PotionSMP plugin;
    private final Map<UUID, Integer> activeTasks = new HashMap<>();

    public FireAuraManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public void activateInfernoAura(Player player, int durationTicks, int radius) {
        UUID uid = player.getUniqueId();
        double dps = plugin.getConfig().getDouble("potions.fire.damage-per-second", 2.0);

        Integer existing = activeTasks.remove(uid);
        if (existing != null) plugin.getServer().getScheduler().cancelTask(existing);

        BukkitRunnable auraTask = new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks >= durationTicks || !player.isOnline()) {
                    activeTasks.remove(uid);
                    cancel();
                    return;
                }

                Location center = player.getLocation();

                if (ticks % 20 == 0) {
                    for (Entity e : center.getWorld().getNearbyEntities(center, radius, 2.5, radius)) {
                        if (e instanceof LivingEntity le && !e.getUniqueId().equals(uid)) {
                            le.damage(dps, player);
                            le.setFireTicks(40);
                        }
                    }
                }

                if (ticks % RING_INTERVAL_TICKS == 0) {
                    drawSectorRing(center);
                }

                ticks++;
            }
        };

        int taskId = auraTask.runTaskTimer(plugin, 0L, 1L).getTaskId();
        activeTasks.put(uid, taskId);
    }

    // ── Flat ring geometry ──────────────────────────────────────────────
    // Fixed visual radius/diameter per spec — independent of the gameplay
    // damage radius (potions.fire.active-fire-radius), which is untouched.
    private static final double RING_RADIUS = 10.0;
    // 32 points around a 10-block-radius circle (~2 blocks between points) —
    // enough to read clearly as a circle without excessive particle count.
    private static final int RING_POINTS = 32;
    // Draw the ring 5x/second (every 4 ticks) instead of every tick (20x/sec)
    // — this alone is the main fix for the FPS drop seen in testing.
    private static final int RING_INTERVAL_TICKS = 4;

    /**
     * Draws a FLAT horizontal ring (single Y, ground/foot level) centered
     * exactly on the player, radius 10 / diameter 20, using the required
     * x = centerX + r*cos(angle), z = centerZ + r*sin(angle) formula.
     * Never varies Y across the loop, so this cannot render as a vertical
     * circle, cylinder, or sphere — it is always flat on the ground plane.
     * The 4 required 90° sections are made visually distinguishable by
     * alternating particle type per quadrant (no extra geometry/particles
     * needed for this, keeping particle density low).
     */
    private void drawSectorRing(Location center) {
        double groundY = center.getY() + 0.05; // foot level, tiny lift only to avoid ground z-fighting
        World world = center.getWorld();

        for (int i = 0; i < RING_POINTS; i++) {
            double angle = (2 * Math.PI * i) / RING_POINTS;
            double x = center.getX() + RING_RADIUS * Math.cos(angle);
            double z = center.getZ() + RING_RADIUS * Math.sin(angle);
            Location point = new Location(world, x, groundY, z);

            // Which 90° section (0-90, 90-180, 180-270, 270-360) this point
            // falls in — alternate particle type per section so all 4 are
            // visually distinguishable along the flat ring.
            int section = (int) (angle / (Math.PI / 2.0)) % 4;
            Particle particle = (section % 2 == 0) ? Particle.FLAME : Particle.SOUL_FIRE_FLAME;
            world.spawnParticle(particle, point, 1, 0, 0, 0, 0);
        }

        // Small center wisp so the player still visibly reads as "on fire",
        // throttled to the same interval as the ring to keep density low.
        world.spawnParticle(Particle.FLAME, center.clone().add(0, 0.1, 0), 2, 0.2, 0, 0.2, 0.01);
    }

    public void cancelAura(UUID uid) {
        Integer taskId = activeTasks.remove(uid);
        if (taskId != null) plugin.getServer().getScheduler().cancelTask(taskId);
    }

    public void cancelAll() {
        for (int id : activeTasks.values()) {
            plugin.getServer().getScheduler().cancelTask(id);
        }
        activeTasks.clear();
    }
}
