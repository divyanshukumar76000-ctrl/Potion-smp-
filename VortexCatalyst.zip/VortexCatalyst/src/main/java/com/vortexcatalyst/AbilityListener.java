package com.vortexcatalyst;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;
import net.kyori.adventure.text.Component;

public class AbilityListener implements Listener {

    private final VortexCatalyst plugin;

    public AbilityListener(VortexCatalyst plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        Action action = event.getAction();

        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }

        ItemStack item = player.getInventory().getItemInMainHand();
        if (item == null || item.getType() != org.bukkit.Material.HEART_OF_THE_SEA) {
            return;
        }

        NamespacedKey key = new NamespacedKey(plugin, "artifact_id");
        String artifactId = item.getItemMeta() != null ? 
            item.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING) : null;

        if (!"vortex_catalyst".equals(artifactId)) {
            return;
        }

        if (plugin.getCooldownManager().isCooldownActive(player)) {
            long remaining = plugin.getCooldownManager().getRemainingCooldown(player) / 1000;
            player.sendActionBar(net.kyori.adventure.text.Component.text(ChatColor.RED + "Cooldown: " + remaining + "s"));
            return;
        }

        // Trigger ability
        new VortexAbility(plugin, player).activate();
        
        // Set cooldown
        plugin.getCooldownManager().setCooldown(player, 18000); // 18 seconds
    }
}