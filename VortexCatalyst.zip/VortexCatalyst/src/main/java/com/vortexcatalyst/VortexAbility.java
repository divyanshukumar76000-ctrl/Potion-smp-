package com.vortexcatalyst;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.Collection;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;

public class VortexAbility {

    private final VortexCatalyst plugin;
    private final Player caster;
    private final Location center;
    private BossBar bossBar;
    private BukkitRunnable task;

    public VortexAbility(VortexCatalyst plugin, Player caster) {
        this.plugin = plugin;
        this.caster = caster;
        this.center = caster.getLocation().clone().add(0, 1, 0);
    }

    public void activate() {
        // Title
        caster.showTitle(net.kyori.adventure.title.Title.title(
            net.kyori.adventure.text.Component.text(ChatColor.AQUA + "VORTEX CATALYST"),
            net.kyori.adventure.text.Component.text(ChatColor.GRAY + "Gravity Unleashed"),
            net.kyori.adventure.title.Title.Times.times(
                java.time.Duration.ofMillis(500),
                java.time.Duration.ofMillis(2000),
                java.time.Duration.ofMillis(500)
            )
        ));

        // BossBar
        bossBar = Bukkit.createBossBar(ChatColor.AQUA + "Vortex Active", BarColor.PURPLE, BarStyle.SOLID);
        bossBar.addPlayer(caster);
        bossBar.setProgress(1.0);

        // Start ability task
        task = new BukkitRunnable() {
            int ticks = 0;
            final int duration = 100; // 5 seconds

            @Override
            public void run() {
                if (ticks >= duration) {
                    implosion();
                    cancel();
                    return;
                }

                // Particles
                ParticleRenderer.renderVortex(center, ticks);

                // Physics and effects
                applyVortexEffects(ticks);

                // Update HUD
                double progress = 1.0 - (ticks / (double) duration);
                bossBar.setProgress(progress);

                ticks++;
            }
        };

        task.runTaskTimer(plugin, 0L, 1L); // Every tick
    }

    private void applyVortexEffects(int currentTicks) {
        Collection<Entity> nearby = center.getWorld().getNearbyEntities(center, 10, 10, 10);
        for (Entity entity : nearby) {
            if (entity.equals(caster) || !(entity instanceof LivingEntity)) continue;

            double strength = 0.15 + ((100 - currentTicks) * 0.005);
            VectorPhysicsEngine.pullTowardsCenter(center, entity, strength);

            if (entity instanceof LivingEntity living) {
                living.addPotionEffect(new org.bukkit.potion.PotionEffect(
                    org.bukkit.potion.PotionEffectType.SLOWNESS, 40, 1, false, false));
                living.damage(0.5, caster); // Minor damage
            }
        }
    }

    private void implosion() {
        if (bossBar != null) {
            bossBar.removeAll();
        }

        // Implosion effects
        center.getWorld().spawnParticle(Particle.EXPLOSION_HUGE, center, 1);
        center.getWorld().playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 2.0f, 0.5f);
        center.getWorld().playSound(center, Sound.ENTITY_WITHER_SPAWN, 1.0f, 0.8f);

        // Final burst
        for (int i = 0; i < 50; i++) {
            Location loc = center.clone().add(
                Math.random() * 8 - 4, 
                Math.random() * 8 - 2, 
                Math.random() * 8 - 4
            );
            center.getWorld().spawnParticle(Particle.SONIC_BOOM, loc, 1);
        }

        caster.sendMessage(ChatColor.AQUA + "Vortex implosion complete!");
    }
}