package com.vortexcatalyst;

import org.bukkit.plugin.java.JavaPlugin;

public class VortexCatalyst extends JavaPlugin {

    private static VortexCatalyst instance;
    private CooldownManager cooldownManager;

    @Override
    public void onEnable() {
        instance = this;
        cooldownManager = new CooldownManager();
        getServer().getPluginManager().registerEvents(new AbilityListener(this), this);
        getCommand("vortexgive").setExecutor(new VortexGiveCommand(this));
        getLogger().info("VortexCatalyst has been enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("VortexCatalyst has been disabled!");
    }

    public static VortexCatalyst getInstance() {
        return instance;
    }

    public CooldownManager getCooldownManager() {
        return cooldownManager;
    }
}