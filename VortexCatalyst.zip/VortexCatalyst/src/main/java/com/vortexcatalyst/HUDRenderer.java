package com.vortexcatalyst;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

public class HUDRenderer {

    public static void showCooldown(Player player, long remainingSeconds) {
        player.sendActionBar(ChatColor.YELLOW + "Vortex Cooldown: " + remainingSeconds + "s");
    }

    public static void showReady(Player player) {
        player.sendActionBar(ChatColor.GREEN + "Vortex Catalyst is ready!");
    }
}