package com.vortexcatalyst;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class VortexGiveCommand implements CommandExecutor {

    private final VortexCatalyst plugin;

    public VortexGiveCommand(VortexCatalyst plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Only players can use this command!");
            return true;
        }

        if (!player.hasPermission("vortexcatalyst.give")) {
            player.sendMessage(ChatColor.RED + "You don't have permission to use this command!");
            return true;
        }

        ItemStack item = createVortexCatalyst();
        player.getInventory().addItem(item);
        player.sendMessage(ChatColor.GREEN + "You have received the Vortex Catalyst!");
        return true;
    }

    private ItemStack createVortexCatalyst() {
        ItemStack item = new ItemStack(Material.HEART_OF_THE_SEA);
        ItemMeta meta = item.getItemMeta();

        meta.setDisplayName(ChatColor.AQUA + "" + ChatColor.BOLD + "Vortex Catalyst");
        meta.setLore(java.util.Arrays.asList(
            ChatColor.GRAY + "Right-click to unleash the Vortex!",
            ChatColor.DARK_GRAY + "Cinematic Gravity Ability"
        ));

        // Enchantment glow
        meta.addEnchant(org.bukkit.enchantments.Enchantment.LUCK, 1, true);
        meta.addItemFlags(org.bukkit.inventory.ItemFlag.HIDE_ENCHANTS);

        // PersistentDataContainer
        NamespacedKey key = new NamespacedKey(plugin, "artifact_id");
        meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, "vortex_catalyst");

        item.setItemMeta(meta);
        return item;
    }
}