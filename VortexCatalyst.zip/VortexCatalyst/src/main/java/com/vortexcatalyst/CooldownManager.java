package com.vortexcatalyst;

import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CooldownManager {
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    public boolean isCooldownActive(Player player) {
        return cooldowns.containsKey(player.getUniqueId()) && 
               System.currentTimeMillis() < cooldowns.get(player.getUniqueId());
    }

    public long getRemainingCooldown(Player player) {
        if (!cooldowns.containsKey(player.getUniqueId())) return 0;
        long remaining = cooldowns.get(player.getUniqueId()) - System.currentTimeMillis();
        return Math.max(remaining, 0);
    }

    public void setCooldown(Player player, long milliseconds) {
        cooldowns.put(player.getUniqueId(), System.currentTimeMillis() + milliseconds);
    }

    public void removeCooldown(Player player) {
        cooldowns.remove(player.getUniqueId());
    }
}