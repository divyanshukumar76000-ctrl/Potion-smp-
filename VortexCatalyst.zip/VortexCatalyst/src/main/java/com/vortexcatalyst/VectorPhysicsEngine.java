package com.vortexcatalyst;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.util.Vector;

public class VectorPhysicsEngine {

    public static void pullTowardsCenter(Location center, Entity entity, double strength) {
        Location entityLoc = entity.getLocation();
        Vector direction = center.toVector().subtract(entityLoc.toVector()).normalize();

        // Stronger pull near center
        double distance = center.distance(entityLoc);
        double pullStrength = strength * Math.max(0.2, 1.0 - (distance / 12.0));

        Vector velocity = entity.getVelocity().add(direction.multiply(pullStrength));
        
        // Cap velocity for smoothness
        if (velocity.length() > 1.5) {
            velocity.normalize().multiply(1.5);
        }

        entity.setVelocity(velocity);
    }
}