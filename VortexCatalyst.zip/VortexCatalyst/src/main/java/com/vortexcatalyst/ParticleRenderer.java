package com.vortexcatalyst;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;

public class ParticleRenderer {

    public static void renderVortex(Location center, int tick) {
        World world = center.getWorld();

        // Rotating rings
        double radius = 5.0;
        for (int i = 0; i < 36; i++) {
            double angle = Math.toRadians(i * 10 + tick * 8);
            double x = Math.cos(angle) * radius;
            double z = Math.sin(angle) * radius;
            Location ringLoc = center.clone().add(x, 0, z);
            world.spawnParticle(Particle.PORTAL, ringLoc, 1);

            // Vertical particles
            world.spawnParticle(Particle.SOUL, center.clone().add(x * 0.5, 3, z * 0.5), 1);
        }

        // Energy beam
        for (double y = 0; y < 8; y += 0.5) {
            world.spawnParticle(Particle.DRAGON_BREATH, center.clone().add(0, y, 0), 2);
        }

        // Dark aura
        world.spawnParticle(Particle.SQUID_INK, center, 5, 3, 3, 3, 0.1);

        // Reverse portal for implosion feel
        world.spawnParticle(Particle.REVERSE_PORTAL, center, 10, 2, 4, 2, 0.05);
    }
}