# VortexCatalyst Plugin

Professional Minecraft PaperMC 1.21.1 plugin featuring the cinematic "Vortex Catalyst" gravity ability.

## Building
1. Ensure Maven is installed.
2. Run `mvn clean package` in the project root.
3. The JAR will be in target/VortexCatalyst-1.0-SNAPSHOT.jar

## Features
- Cinematic vortex with particles and physics
- PersistentDataContainer validated item
- Cooldown system
- Multiplayer safe
- Optimized performance

Place the JAR in your PaperMC plugins folder. Use /vortexgive to obtain the item.