package com.tempestcore.ability;

import com.tempestcore.TempestCorePlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class AbilityManager {

    private final TempestCorePlugin plugin;
    private final NamespacedKey abilityKey;          // tempest_item_tag  (physical item)
    private final NamespacedKey arcaneSlot1Key;      // arcane_slot_1     (player PDC state)

    // Runtime tracking sets / maps
    private final Set<UUID> activeAbility = new HashSet<>();
    private final Map<UUID, Map<UUID, BukkitRunnable>> frozenEntities = new HashMap<>();
    private final Map<UUID, Boolean> pearlLockActive = new HashMap<>();
    private final Map<UUID, BukkitTask> taskRegistry = new HashMap<>();
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Map<UUID, Object> snapshotMap = new HashMap<>();
    private final Set<UUID> impactDamageTargets = new HashSet<>();

    // Permanent LUCK effect used to force the client-side potion HUD slot layout
    private static final PotionEffect PERM_LUCK = new PotionEffect(
            PotionEffectType.LUCK,
            PotionEffect.INFINITE_DURATION,
            0,
            true,   // ambient
            false,  // particles
            true    // icon
    );

    public AbilityManager(TempestCorePlugin plugin, NamespacedKey itemKey) {
        this.plugin = plugin;
        this.abilityKey = itemKey;
        this.arcaneSlot1Key = new NamespacedKey(plugin, "arcane_slot_1");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PDC State helpers
    // ─────────────────────────────────────────────────────────────────────────

    /** Returns true if this player has "TEMPEST" written in arcane_slot_1. */
    public boolean hasAbsorbedTempest(Player player) {
        String val = player.getPersistentDataContainer()
                .getOrDefault(arcaneSlot1Key, PersistentDataType.STRING, "NONE");
        return "TEMPEST".equals(val);
    }

    /**
     * Write "TEMPEST" into the player's arcane_slot_1 PDC key
     * and apply the permanent LUCK effect so the potion icon box appears in the HUD.
     */
    public void absorbTempestCore(Player player) {
        player.getPersistentDataContainer()
                .set(arcaneSlot1Key, PersistentDataType.STRING, "TEMPEST");
        applyLuckEffect(player);
    }

    /** Apply (or re-apply) the permanent LUCK effect. Thread-safe via sync task. */
    public void applyLuckEffect(Player player) {
        Bukkit.getScheduler().runTask(plugin, () ->
                player.addPotionEffect(PERM_LUCK));
    }

    /** Schedule re-application after a 1-tick delay (e.g. after milk bucket removal). */
    public void scheduleReapplyLuck(Player player, long delayTicks) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (hasAbsorbedTempest(player)) {
                player.addPotionEffect(PERM_LUCK);
            }
        }, delayTicks);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Cooldown helpers
    // ─────────────────────────────────────────────────────────────────────────

    public boolean isOnCooldown(Player player) {
        UUID uuid = player.getUniqueId();
        if (!cooldowns.containsKey(uuid)) return false;
        long remaining = cooldowns.get(uuid) - System.currentTimeMillis();
        return remaining > 0;
    }

    public long getCooldownRemaining(Player player) {
        UUID uuid = player.getUniqueId();
        if (!cooldowns.containsKey(uuid)) return 0;
        return Math.max(0, cooldowns.get(uuid) - System.currentTimeMillis());
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Ability item creation (from original JAR + v1 style)
    // ─────────────────────────────────────────────────────────────────────────

    public ItemStack createAbilityItem() {
        ItemStack item = new ItemStack(Material.NETHER_STAR);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        // Display name — Adventure API (matches v1)
        meta.displayName(Component.text("⚡ Tempest Core", NamedTextColor.YELLOW)
                .decoration(TextDecoration.ITALIC, false)
                .decorate(TextDecoration.BOLD));

        // Lore
        Component lore1 = Component.text("Right-Click", NamedTextColor.AQUA)
                .append(Component.text(" to absorb the storm's soul", NamedTextColor.GRAY));
        Component lore2 = Component.text("Shift + Right-Click", NamedTextColor.AQUA)
                .append(Component.text(" to unleash Tempest", NamedTextColor.GRAY));
        Component lore3 = Component.empty();
        Component lore4 = Component.text("Cooldown: 30s", NamedTextColor.DARK_GRAY);
        meta.lore(List.of(lore1, lore2, lore3, lore4));

        // Glow effect
        meta.addEnchant(Enchantment.UNBREAKING, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

        // NBT tag so the interact listener can validate it
        meta.getPersistentDataContainer()
                .set(abilityKey, PersistentDataType.STRING, "tempest_core");

        item.setItemMeta(meta);
        return item;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Ability trigger — exact 3-phase logic from the original JAR
    // ─────────────────────────────────────────────────────────────────────────

    public void triggerAbility(Player player) {
        UUID casterUUID = player.getUniqueId();

        if (activeAbility.contains(casterUUID)) {
            player.sendMessage(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                    .legacyAmpersand().deserialize("&5⚡ Tempest Core is already active!"));
            return;
        }

        if (isOnCooldown(player)) {
            long secs = getCooldownRemaining(player) / 1000;
            player.sendMessage(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                    .legacyAmpersand().deserialize(
                            "&eⓘ &7Ability on cooldown! &e" + secs + "s &7remaining."));
            return;
        }

        if (!player.isOnGround()) {
            player.sendMessage(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                    .legacyAmpersand().deserialize("&eⓘ &7You must be on the ground to use Tempest Core!"));
            return;
        }

        World world = player.getWorld();
        activeAbility.add(casterUUID);
        cooldowns.put(casterUUID, System.currentTimeMillis() + 30_000L);

        // Phase 1 — Lock-in
        phaseLockIn(player, world);

        // Phase 2 — Ascent (delayed 20 ticks after lock-in)
        BukkitTask ascentTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (activeAbility.contains(casterUUID)) phaseAscent(player);
        }, 20L);
        registerTask(casterUUID, ascentTask);

        // Phase 3 — Gravity drop (delayed 60 ticks after ascent start)
        BukkitTask dropTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (activeAbility.contains(casterUUID)) phaseGravityDrop(player, casterUUID);
        }, 80L);
        registerTask(casterUUID, dropTask);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Phase 1: Lock-in — freeze nearby enemies, storm weather
    // ─────────────────────────────────────────────────────────────────────────

    private void phaseLockIn(Player caster, World world) {
        UUID casterUUID = caster.getUniqueId();

        // Start storm
        world.setStorm(true);
        world.setThundering(true);

        // Freeze nearby entities
        Collection<Entity> nearby = caster.getLocation().getNearbyEntities(10, 10, 10);
        for (Entity entity : nearby) {
            if (!(entity instanceof LivingEntity living)) continue;
            if (entity.equals(caster)) continue;

            UUID enemyUUID = entity.getUniqueId();
            frozenEntities.computeIfAbsent(casterUUID, k -> new HashMap<>());

            // Ice particle loop per frozen entity
            BukkitRunnable iceLoop = new BukkitRunnable() {
                @Override
                public void run() {
                    if (!frozenEntities.containsKey(casterUUID)
                            || !frozenEntities.get(casterUUID).containsKey(enemyUUID)) {
                        cancel();
                        return;
                    }
                    org.bukkit.Location eLoc = living.getLocation().add(0, 1, 0);
                    world.spawnParticle(Particle.SNOWFLAKE, eLoc, 5, 0.3, 0.5, 0.3, 0);
                    ItemStack iceItem = new ItemStack(Material.ICE);
                    world.spawnParticle(Particle.ITEM, eLoc, 3, 0.2, 0.3, 0.2, 0.05, iceItem);
                }
            };
            iceLoop.runTaskTimer(plugin, 0L, 4L);
            frozenEntities.get(casterUUID).put(enemyUUID, iceLoop);
        }

        // Visual on caster
        world.spawnParticle(Particle.DRAGON_BREATH, caster.getLocation().add(0, 1, 0), 30, 0.5, 0.5, 0.5, 0.1);
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5f, 1.2f);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Phase 2: Ascent — spiral particle ascent
    // ─────────────────────────────────────────────────────────────────────────

    private void phaseAscent(Player caster) {
        UUID casterUUID = caster.getUniqueId();
        World world = caster.getWorld();
        int[] tickCount = {0};
        double[] angle = {0};

        BukkitRunnable spiralLoop = new BukkitRunnable() {
            @Override
            public void run() {
                if (!activeAbility.contains(casterUUID)) {
                    cancel();
                    return;
                }
                tickCount[0]++;
                angle[0] += 20;
                if (tickCount[0] > 30) {
                    cancel();
                    return;
                }

                org.bukkit.Location center = caster.getLocation().add(0, 1, 0);
                double rad = Math.toRadians(angle[0]);
                double x = Math.cos(rad) * 1.5;
                double z = Math.sin(rad) * 1.5;

                org.bukkit.Location above = center.clone().add(x, 0, z);
                world.spawnParticle(Particle.DRAGON_BREATH, above, 3, 0.1, 0.1, 0.1, 0.02);
                world.spawnParticle(Particle.SOUL_FIRE_FLAME, above, 1, 0, 0, 0, 0.05);
                if (Math.random() < 0.3) {
                    world.spawnParticle(Particle.END_ROD, above, 1, 0, 0.1, 0, 0.05);
                }
                if (Math.random() < 0.2) {
                    world.spawnParticle(Particle.ENCHANT, center, 5, 0.5, 0.5, 0.5, 1);
                }
            }
        };
        spiralLoop.runTaskTimer(plugin, 0L, 2L);
        registerTask(casterUUID, spiralLoop.runTaskTimer(plugin, 0L, 2L));
        // Apply velocity upward
        caster.setVelocity(caster.getLocation().getDirection().setY(1.8));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Phase 3: Gravity Drop — detect landing, trigger impact
    // ─────────────────────────────────────────────────────────────────────────

    private void phaseGravityDrop(Player caster, UUID casterUUID) {
        // Apply downward velocity
        caster.setVelocity(caster.getVelocity().setY(-3.0));

        BukkitRunnable landingCheck = new BukkitRunnable() {
            @Override
            public void run() {
                if (!activeAbility.contains(casterUUID)) {
                    cancel();
                    return;
                }
                org.bukkit.Location loc = caster.getLocation();
                Block blockBelow = loc.getWorld().getBlockAt(
                        loc.getBlockX(), loc.getBlockY() - 1, loc.getBlockZ());
                Material mat = blockBelow.getType();

                if (mat != Material.AIR && mat != Material.VOID_AIR && mat != Material.CAVE_AIR) {
                    cancel();
                    triggerImpact(caster);
                }
            }
        };
        BukkitTask task = landingCheck.runTaskTimer(plugin, 0L, 1L);
        registerTask(casterUUID, task);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Impact — shockwave, AOE damage, clean up
    // ─────────────────────────────────────────────────────────────────────────

    private void triggerImpact(Player caster) {
        UUID casterUUID = caster.getUniqueId();
        World world = caster.getWorld();
        org.bukkit.Location impactLoc = caster.getLocation();

        // Lightning effect
        world.strikeLightningEffect(impactLoc);
        world.playSound(impactLoc, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1.5f, 0.8f);

        // AOE damage to nearby entities
        Collection<Entity> nearby = impactLoc.getNearbyEntities(6, 4, 6);
        for (Entity entity : nearby) {
            if (!(entity instanceof LivingEntity living)) continue;
            if (entity.equals(caster)) continue;
            living.damage(8.0, caster);
            living.setVelocity(entity.getLocation()
                    .subtract(impactLoc).toVector().normalize().multiply(1.5).setY(0.8));
        }

        // Electric spark burst
        BukkitRunnable sparkLoop = new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                ticks++;
                if (ticks > 10) { cancel(); return; }
                for (int i = 0; i < 8; i++) {
                    double rx = (Math.random() - 0.5) * 4;
                    double rz = (Math.random() - 0.5) * 4;
                    world.spawnParticle(Particle.ELECTRIC_SPARK,
                            impactLoc.clone().add(rx, 0.5, rz), 3, 0.2, 0.2, 0.2, 0.05);
                }
            }
        };
        sparkLoop.runTaskTimer(plugin, 0L, 2L);

        // Unfreeze entities and end ability
        fullCleanup(casterUUID);
        // Stop storm after 5 s
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            world.setStorm(false);
            world.setThundering(false);
        }, 100L);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Cleanup helpers
    // ─────────────────────────────────────────────────────────────────────────

    public void fullCleanup(UUID uuid) {
        activeAbility.remove(uuid);

        // Cancel any registered tasks
        BukkitTask task = taskRegistry.remove(uuid);
        if (task != null) {
            try { task.cancel(); } catch (Exception ignored) {}
        }

        // Cancel all freeze loops for this caster
        Map<UUID, BukkitRunnable> frozen = frozenEntities.remove(uuid);
        if (frozen != null) {
            for (BukkitRunnable r : frozen.values()) {
                try { r.cancel(); } catch (Exception ignored) {}
            }
        }

        pearlLockActive.remove(uuid);
    }

    public void removeFrozenEnemy(UUID casterUUID, UUID enemyUUID) {
        Map<UUID, BukkitRunnable> map = frozenEntities.get(casterUUID);
        if (map == null) return;
        BukkitRunnable r = map.remove(enemyUUID);
        if (r != null) {
            try { r.cancel(); } catch (Exception ignored) {}
        }
    }

    private void registerTask(UUID uuid, BukkitTask task) {
        BukkitTask old = taskRegistry.put(uuid, task);
        if (old != null) {
            try { old.cancel(); } catch (Exception ignored) {}
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Accessors used by listeners
    // ─────────────────────────────────────────────────────────────────────────

    public Set<UUID> getActiveAbility() { return activeAbility; }
    public Map<UUID, Map<UUID, BukkitRunnable>> getFrozenEntities() { return frozenEntities; }
    public Map<UUID, Boolean> getPearlLockActive() { return pearlLockActive; }
    public NamespacedKey getArcaneSlot1Key() { return arcaneSlot1Key; }
    public NamespacedKey getAbilityKey() { return abilityKey; }
    public TempestCorePlugin getPlugin() { return plugin; }
}
