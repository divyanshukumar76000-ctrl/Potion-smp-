package com.tempestcore.commands;

import com.tempestcore.TempestCorePlugin;
import com.tempestcore.ability.AbilityManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class TempestCoreCommand implements CommandExecutor, TabCompleter {

    private final TempestCorePlugin plugin;
    private final AbilityManager abilityManager;

    public TempestCoreCommand(TempestCorePlugin plugin, AbilityManager abilityManager) {
        this.plugin = plugin;
        this.abilityManager = abilityManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("tempestcore.admin")) {
            sender.sendMessage("§cYou don't have permission to use this command.");
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage("§5=== TempestCore ===");
            sender.sendMessage("§7/tempestcore give [player] — gives the Tempest Core item");
            return true;
        }

        if ("give".equalsIgnoreCase(args[0])) {
            Player target;
            if (args.length >= 2) {
                target = plugin.getServer().getPlayer(args[1]);
                if (target == null) {
                    sender.sendMessage("§cPlayer '" + args[1] + "' not found.");
                    return true;
                }
            } else if (sender instanceof Player) {
                target = (Player) sender;
            } else {
                sender.sendMessage("§cConsole must specify a player: /tempestcore give <player>");
                return true;
            }

            ItemStack item = abilityManager.createAbilityItem();
            target.getInventory().addItem(item);
            target.sendMessage("§5⚡ §7You received the §5§lTempest Core§r §7ability item!");
            if (!target.equals(sender)) {
                sender.sendMessage("§aGave Tempest Core item to §f" + target.getName() + "§a.");
            }
            return true;
        }

        sender.sendMessage("§cUnknown sub-command. Use /tempestcore give.");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Arrays.asList("give");
        }
        if (args.length == 2 && "give".equalsIgnoreCase(args[0])) {
            List<String> names = new ArrayList<>();
            plugin.getServer().getOnlinePlayers().forEach(p -> names.add(p.getName()));
            return names;
        }
        return Collections.emptyList();
    }
}
