package com.tempestcore.listeners;

import com.tempestcore.ability.AbilityManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.Material;

import java.util.UUID;

/**
 * Persistence layer safeguards:
 *
 * 1. PlayerDeathEvent  → full ability cleanup (runtime sets), but PDC state survives.
 * 2. PlayerQuitEvent   → same runtime cleanup.
 * 3. PlayerChangedWorldEvent → cleanup if ability active in old world.
 * 4. PlayerItemConsumeEvent (MILK_BUCKET) → re-apply LUCK effect after 1 tick.
 * 5. PlayerRespawnEvent → re-apply LUCK effect after 20 ticks.
 */
public class PlayerStateListener implements Listener {

    private final AbilityManager abilityManager;

    public PlayerStateListener(AbilityManager abilityManager) {
        this.abilityManager = abilityManager;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player dead = event.getPlayer();
        UUID deadUUID = dead.getUniqueId();

        // Clean up runtime ability state (PDC arcane_slot_1 persists through death)
        if (abilityManager.getActiveAbility().contains(deadUUID)) {
            abilityManager.fullCleanup(deadUUID);
        }

        // Also unfreeze any frozen enemies that were bound to this player
        boolean isFrozenEnemy = abilityManager.getFrozenEntities().values().stream()
                .anyMatch(map -> map.containsKey(deadUUID));
        if (isFrozenEnemy) {
            abilityManager.getFrozenEntities().forEach((casterUUID, map) -> {
                if (map.containsKey(deadUUID)) {
                    abilityManager.removeFrozenEnemy(casterUUID, deadUUID);
                }
            });
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        abilityManager.getActiveAbility().remove(uuid);
        abilityManager.getPearlLockActive().remove(uuid);
        abilityManager.getFrozenEntities().remove(uuid);
    }

    @EventHandler
    public void onPlayerChangedWorld(PlayerChangedWorldEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        if (abilityManager.getActiveAbility().contains(uuid)) {
            abilityManager.fullCleanup(uuid);
        }
    }

    /**
     * Milk bucket removes all potion effects — re-apply LUCK after 1 tick
     * so the HUD slot box stays visible.
     */
    @EventHandler
    public void onPlayerItemConsume(PlayerItemConsumeEvent event) {
        if (event.getItem().getType() != Material.MILK_BUCKET) return;
        Player player = event.getPlayer();
        if (!abilityManager.hasAbsorbedTempest(player)) return;

        // 1-tick delayed synchronous re-apply
        abilityManager.scheduleReapplyLuck(player, 1L);
    }

    /**
     * After respawn, re-apply LUCK effect with a 20-tick delay
     * (player entity isn't fully ready at the respawn event moment).
     */
    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        if (!abilityManager.hasAbsorbedTempest(player)) return;

        abilityManager.scheduleReapplyLuck(player, 20L);
    }
}
