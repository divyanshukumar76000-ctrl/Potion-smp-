package com.tempestcore.listeners;

import com.tempestcore.ability.AbilityManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.UUID;

/**
 * Prevents ender pearl teleportation while ability is active (pearl lock)
 * and tracks movement during the ability phases.
 */
public class PlayerMoveListener implements Listener {

    private final AbilityManager abilityManager;

    public PlayerMoveListener(AbilityManager abilityManager) {
        this.abilityManager = abilityManager;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();

        // If ability is active and pearl lock is on, cancel horizontal movement
        Boolean pearlLock = abilityManager.getPearlLockActive().get(uuid);
        if (pearlLock != null && pearlLock) {
            // Allow vertical movement only during ascent/drop phases
            if (event.getFrom().getX() != event.getTo().getX()
                    || event.getFrom().getZ() != event.getTo().getZ()) {
                event.setTo(event.getFrom().setDirection(event.getTo().getDirection()));
            }
        }
    }
}
