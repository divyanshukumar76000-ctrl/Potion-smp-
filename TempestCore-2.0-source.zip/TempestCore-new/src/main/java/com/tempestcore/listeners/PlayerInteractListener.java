package com.tempestcore.listeners;

import com.tempestcore.TempestCorePlugin;
import com.tempestcore.ability.AbilityManager;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

/**
 * Handles two distinct interaction paths:
 *
 * SNEAKING (Shift + Right-Click):
 *   → Bypass item check entirely.
 *   → If absorbed: trigger ability immediately (works with empty hand or sword).
 *   → If not absorbed: send error message.
 *
 * NOT SNEAKING (Right-Click with item):
 *   → Require physical item with NBT tag "tempest_item_tag" = "tempest_core".
 *   → Consume 1 item, write "TEMPEST" into arcane_slot_1 PDC, apply LUCK HUD effect.
 */
public class PlayerInteractListener implements Listener {

    private final TempestCorePlugin plugin;
    private final AbilityManager abilityManager;

    public PlayerInteractListener(TempestCorePlugin plugin, AbilityManager abilityManager) {
        this.plugin = plugin;
        this.abilityManager = abilityManager;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();

        // ── SNEAK PATH ──────────────────────────────────────────────────────
        if (player.isSneaking()) {
            event.setCancelled(true);

            if (abilityManager.hasAbsorbedTempest(player)) {
                abilityManager.triggerAbility(player);
            } else {
                player.sendMessage("❌ Pehle Core ko absorb karo!");
            }
            return;
        }

        // ── NORMAL PATH (physical item required) ────────────────────────────
        ItemStack item = event.getItem();
        if (item == null || item.getType() == Material.AIR) return;
        if (!item.hasItemMeta()) return;

        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;

        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        if (!pdc.has(plugin.getAbilityKey(), PersistentDataType.STRING)) return;

        String tag = pdc.get(plugin.getAbilityKey(), PersistentDataType.STRING);
        if (!"tempest_core".equals(tag)) return;

        // Item is valid — now absorb
        event.setCancelled(true);

        if (abilityManager.hasAbsorbedTempest(player)) {
            player.sendMessage("❌ Tumhari rooh me pehle se Tempest Core active hai!");
            return;
        }

        // Consume 1 item from stack
        int amount = item.getAmount();
        if (amount <= 1) {
            player.getInventory().setItemInMainHand(null);
        } else {
            item.setAmount(amount - 1);
        }

        // Write TEMPEST into PDC + apply LUCK HUD effect
        abilityManager.absorbTempestCore(player);

        // Sound + confirmation
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_PLAYER_BURP, 1f, 0.8f);
        player.sendMessage("✅ Tempest Core absorbed! HUD active.");
    }
}
