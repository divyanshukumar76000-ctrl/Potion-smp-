package com.tempestcore.listeners;

import com.tempestcore.ability.AbilityManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerTeleportEvent;

import java.util.UUID;

/**
 * Cancels ender-pearl teleports while the ability pearl-lock is active.
 */
public class TeleportListener implements Listener {

    private final AbilityManager abilityManager;

    public TeleportListener(AbilityManager abilityManager) {
        this.abilityManager = abilityManager;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        if (event.getCause() != PlayerTeleportEvent.TeleportCause.ENDER_PEARL) return;
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();

        Boolean lock = abilityManager.getPearlLockActive().get(uuid);
        if (lock != null && lock) {
            event.setCancelled(true);
            player.sendMessage("§5⚡ Pearl teleport locked during Tempest ability!");
        }
    }
}
