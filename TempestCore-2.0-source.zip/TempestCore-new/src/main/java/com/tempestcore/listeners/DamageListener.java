package com.tempestcore.listeners;

import com.tempestcore.ability.AbilityManager;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;

import java.util.UUID;

/**
 * Blocks damage to frozen entities, and handles impact-damage tracking.
 */
public class DamageListener implements Listener {

    private final AbilityManager abilityManager;

    public DamageListener(AbilityManager abilityManager) {
        this.abilityManager = abilityManager;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageEvent event) {
        Entity entity = event.getEntity();
        if (!(entity instanceof LivingEntity)) return;
        UUID targetUUID = entity.getUniqueId();

        // Cancel all incoming damage for frozen entities
        boolean isFrozen = abilityManager.getFrozenEntities().values().stream()
                .anyMatch(map -> map.containsKey(targetUUID));
        if (isFrozen) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        // Prevent the ability caster from taking fall damage during the drop phase
        if (!(event.getEntity() instanceof Player player)) return;
        UUID uuid = player.getUniqueId();
        if (event.getCause() == EntityDamageEvent.DamageCause.FALL
                && abilityManager.getActiveAbility().contains(uuid)) {
            event.setCancelled(true);
        }
    }
}
