package com.tempestcore;

import com.tempestcore.ability.AbilityManager;
import com.tempestcore.commands.TempestCoreCommand;
import com.tempestcore.hud.HUDRenderer;
import com.tempestcore.listeners.DamageListener;
import com.tempestcore.listeners.PlayerInteractListener;
import com.tempestcore.listeners.PlayerMoveListener;
import com.tempestcore.listeners.PlayerStateListener;
import com.tempestcore.listeners.TeleportListener;
import org.bukkit.NamespacedKey;
import org.bukkit.plugin.java.JavaPlugin;

public class TempestCorePlugin extends JavaPlugin {

    private NamespacedKey abilityKey;
    private AbilityManager abilityManager;

    @Override
    public void onEnable() {
        // Physical item tag key (for hand-item validation)
        abilityKey = new NamespacedKey(this, "tempest_item_tag");

        abilityManager = new AbilityManager(this, abilityKey);

        var pm = getServer().getPluginManager();
        pm.registerEvents(new PlayerInteractListener(this, abilityManager), this);
        pm.registerEvents(new PlayerMoveListener(abilityManager), this);
        pm.registerEvents(new DamageListener(abilityManager), this);
        pm.registerEvents(new TeleportListener(abilityManager), this);
        pm.registerEvents(new PlayerStateListener(abilityManager), this);

        // Register /tempestcore command
        var cmd = new TempestCoreCommand(this, abilityManager);
        var pluginCmd = getCommand("tempestcore");
        if (pluginCmd != null) {
            pluginCmd.setExecutor(cmd);
            pluginCmd.setTabCompleter(cmd);
        }

        // Start async HUD renderer — every 5 ticks (0.25 s)
        new HUDRenderer(abilityManager).runTaskTimerAsynchronously(this, 0L, 5L);

        getLogger().info("TempestCore v1.0 enabled — Storm. Ascend. Strike.");
    }

    @Override
    public void onDisable() {
        // Clean up all active abilities on shutdown
        for (java.util.UUID uuid : new java.util.HashSet<>(abilityManager.getActiveAbility())) {
            abilityManager.fullCleanup(uuid);
        }
        getLogger().info("TempestCore disabled. All active abilities cleaned up.");
    }

    public NamespacedKey getAbilityKey() {
        return abilityKey;
    }

    public AbilityManager getAbilityManager() {
        return abilityManager;
    }
}
