package com.tempestcore.hud;

import com.tempestcore.ability.AbilityManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Async HUD renderer — fires every 5 ticks (0.25 s).
 *
 * Action-bar layout:
 *   If absorbed  →  [⚡ TEMPEST]   [🔒 SLOT 2]
 *   Otherwise    →  [🔒 EMPTY]     [🔒 SLOT 2]
 */
public class HUDRenderer extends BukkitRunnable {

    private final AbilityManager abilityManager;

    // Pre-built component pieces (thread-safe; Component is immutable)
    private static final Component SLOT2_SUFFIX = Component.text("   ")
            .append(Component.text("[🔒 SLOT 2]", NamedTextColor.DARK_GRAY));

    private static final Component ACTIVE_HUD = Component.text("[⚡ TEMPEST]", NamedTextColor.YELLOW)
            .append(SLOT2_SUFFIX);

    private static final Component EMPTY_HUD = Component.text("[🔒 EMPTY]", NamedTextColor.GRAY)
            .append(SLOT2_SUFFIX);

    public HUDRenderer(AbilityManager abilityManager) {
        this.abilityManager = abilityManager;
    }

    @Override
    public void run() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            boolean hasTempest = abilityManager.hasAbsorbedTempest(player);
            Component hudMessage = hasTempest ? ACTIVE_HUD : EMPTY_HUD;
            player.sendActionBar(hudMessage);
        }
    }
}
