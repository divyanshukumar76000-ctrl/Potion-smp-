package com.tempestcore.commands;

import com.tempestcore.TempestCorePlugin;
import com.tempestcore.ability.AbilityManager;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.NamespacedKey;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class TempestCoreCommand implements CommandExecutor, TabCompleter {

    private final TempestCorePlugin plugin;
    private final NamespacedKey abilityKey;

    public TempestCoreCommand(TempestCorePlugin plugin, NamespacedKey abilityKey) {
        this.plugin = plugin;
        this.abilityKey = abilityKey;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("tempestcore.admin")) {
            sender.sendMessage(ChatColor.RED + "You don't have permission to use this command.");
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage(ChatColor.DARK_PURPLE + "=== TempestCore ===");
            sender.sendMessage(ChatColor.GRAY + "/tempestcore give — gives the Tempest Core item");
            return true;
        }

        if (args[0].equalsIgnoreCase("give")) {
            Player target;
            if (args.length >= 2) {
                target = plugin.getServer().getPlayer(args[1]);
                if (target == null) {
                    sender.sendMessage(ChatColor.RED + "Player '" + args[1] + "' not found.");
                    return true;
                }
            } else {
                if (!(sender instanceof Player)) {
                    sender.sendMessage(ChatColor.RED + "Console must specify a player: /tempestcore give <player>");
                    return true;
                }
                target = (Player) sender;
            }

            ItemStack item = plugin.getAbilityManager().createAbilityItem();
            target.getInventory().addItem(item);
            target.sendMessage(ChatColor.DARK_PURPLE + "⚡ " + ChatColor.WHITE + "You received the "
                    + ChatColor.DARK_PURPLE + ChatColor.BOLD + "Tempest Core" + ChatColor.WHITE + " ability item!");
            if (!target.equals(sender)) {
                sender.sendMessage(ChatColor.GREEN + "Gave Tempest Core item to " + target.getName() + ".");
            }
            return true;
        }

        sender.sendMessage(ChatColor.RED + "Unknown sub-command. Use /tempestcore give.");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Arrays.asList("give");
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            // Return online player names
            List<String> names = new java.util.ArrayList<>();
            for (Player p : plugin.getServer().getOnlinePlayers()) {
                names.add(p.getName());
            }
            return names;
        }
        return Collections.emptyList();
    }
}
