package com.tempestcore.listeners;

import com.tempestcore.ability.AbilityManager;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.Map;
import java.util.UUID;

public class PlayerMoveListener implements Listener {

    private final AbilityManager manager;

    public PlayerMoveListener(AbilityManager manager) {
        this.manager = manager;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        UUID playerUUID = player.getUniqueId();

        // Check if this player is a frozen enemy
        Location lockedLocation = null;
        for (Map<UUID, Location> frozenMap : manager.getFrozenEntities().values()) {
            if (frozenMap.containsKey(playerUUID)) {
                lockedLocation = frozenMap.get(playerUUID);
                break;
            }
        }

        if (lockedLocation == null) return;

        // Allow very slight vertical movement for visual stability, but lock horizontal
        Location from = event.getFrom();
        Location to = event.getTo();

        if (to == null) return;

        // Check if there's any horizontal movement
        boolean horizontalMoved = (Math.abs(to.getX() - lockedLocation.getX()) > 0.01)
                || (Math.abs(to.getZ() - lockedLocation.getZ()) > 0.01);

        if (horizontalMoved) {
            // Cancel the move event to prevent horizontal movement
            // This is safer than teleporting inside PlayerMoveEvent (avoids event loop)
            Location resetTo = lockedLocation.clone();
            resetTo.setYaw(to.getYaw());
            resetTo.setPitch(to.getPitch());
            // Allow small vertical offset for gravity/visual stability
            double yDiff = to.getY() - lockedLocation.getY();
            if (Math.abs(yDiff) <= 1.0) {
                resetTo.setY(to.getY());
            }
            event.setTo(resetTo);
        }
    }
}
