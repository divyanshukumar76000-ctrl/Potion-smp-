package com.tempestcore.listeners;

import com.tempestcore.ability.AbilityManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityTeleportEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

public class TeleportListener implements Listener {

    private final AbilityManager manager;

    public TeleportListener(AbilityManager manager) {
        this.manager = manager;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        // Block ender pearl teleports for frozen players
        if (!manager.getPearlLockActive().contains(event.getPlayer().getUniqueId())) return;
        if (event.getCause() == PlayerTeleportEvent.TeleportCause.ENDER_PEARL) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
    public void onEntityTeleport(EntityTeleportEvent event) {
        // Block ender pearl teleports for frozen entities (non-player)
        if (!manager.getPearlLockActive().contains(event.getEntity().getUniqueId())) return;
        event.setCancelled(true);
    }
}
