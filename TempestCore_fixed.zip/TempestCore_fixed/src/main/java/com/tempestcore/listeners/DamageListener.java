package com.tempestcore.listeners;

import com.tempestcore.ability.AbilityManager;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

public class DamageListener implements Listener {

    private final AbilityManager manager;

    public DamageListener(AbilityManager manager) {
        this.manager = manager;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
    public void onEntityDamage(EntityDamageEvent event) {
        Entity entity = event.getEntity();

        // --- FALL DAMAGE IMMUNITY for active casters ---
        if (entity instanceof Player player) {
            if (manager.getActiveAbility().contains(player.getUniqueId())) {
                if (event.getCause() == EntityDamageEvent.DamageCause.FALL) {
                    event.setCancelled(true);
                    return;
                }
            }
        }

        // --- TRUE DAMAGE bypass (armor ignore) for impact targets ---
        if (entity instanceof LivingEntity) {
            if (manager.getImpactDamageTargets().contains(entity.getUniqueId())) {
                // Remove from set so only one event is intercepted
                manager.getImpactDamageTargets().remove(entity.getUniqueId());
                // Flat 10 damage ignoring all modifiers (armor, resistance, enchants)
                // setDamage(BASE) alone sets the raw hit; we override final damage directly
                event.setDamage(10.0);
                // Zero out all applicable damage modifiers to bypass armor/enchants
                for (EntityDamageEvent.DamageModifier modifier : EntityDamageEvent.DamageModifier.values()) {
                    if (modifier == EntityDamageEvent.DamageModifier.BASE) continue;
                    try {
                        if (event.isApplicable(modifier)) {
                            event.setDamage(modifier, 0.0);
                        }
                    } catch (UnsupportedOperationException ignored) {}
                }
            }
        }
    }
}
