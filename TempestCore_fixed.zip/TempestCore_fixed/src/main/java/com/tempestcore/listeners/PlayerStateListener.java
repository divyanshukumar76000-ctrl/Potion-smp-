package com.tempestcore.listeners;

import com.tempestcore.ability.AbilityManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.UUID;

public class PlayerStateListener implements Listener {

    private final AbilityManager manager;

    public PlayerStateListener(AbilityManager manager) {
        this.manager = manager;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player dead = event.getPlayer();
        UUID deadUUID = dead.getUniqueId();

        // If caster dies: full cleanup
        if (manager.getActiveAbility().contains(deadUUID)) {
            manager.fullCleanup(deadUUID);
            return;
        }

        // If a frozen enemy dies: only remove from relevant maps
        boolean isFrozenEnemy = manager.getFrozenEntities().values()
                .stream()
                .anyMatch(map -> map.containsKey(deadUUID));

        if (isFrozenEnemy) {
            manager.removeFrozenEnemy(deadUUID);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerQuit(PlayerQuitEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        if (manager.getActiveAbility().contains(uuid)) {
            manager.fullCleanup(uuid);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerChangedWorld(PlayerChangedWorldEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        if (manager.getActiveAbility().contains(uuid)) {
            manager.fullCleanup(uuid);
        }
    }
}
