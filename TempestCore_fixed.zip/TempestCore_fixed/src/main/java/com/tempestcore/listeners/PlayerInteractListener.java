package com.tempestcore.listeners;

import com.tempestcore.TempestCorePlugin;
import com.tempestcore.ability.AbilityManager;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

public class PlayerInteractListener implements Listener {

    private final AbilityManager manager;
    private final NamespacedKey abilityKey;

    public PlayerInteractListener(AbilityManager manager, NamespacedKey abilityKey) {
        this.manager = manager;
        this.abilityKey = abilityKey;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
    public void onPlayerInteract(PlayerInteractEvent event) {
        Action action = event.getAction();

        // Must be right click
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }

        Player player = event.getPlayer();

        // Must be sneaking
        if (!player.isSneaking()) {
            return;
        }

        // Must have item in main hand
        ItemStack item = event.getItem();
        if (item == null || !item.hasItemMeta()) {
            return;
        }

        // Must have PDC key with correct value
        String abilityId = item.getItemMeta()
                .getPersistentDataContainer()
                .get(abilityKey, PersistentDataType.STRING);
        if (!TempestCorePlugin.ABILITY_ID_VALUE.equals(abilityId)) {
            return;
        }

        // Must not already be using ability
        if (manager.getActiveAbility().contains(player.getUniqueId())) {
            player.sendMessage(ChatColor.RED + "⚡ Tempest Core is already active!");
            return;
        }

        // Must be on ground (server-side check)
        if (!manager.isOnGround(player)) {
            player.sendMessage(ChatColor.YELLOW + "⚡ You must be on the ground to use Tempest Core!");
            return;
        }

        // Must not be on cooldown
        if (manager.isOnCooldown(player.getUniqueId())) {
            long remaining = manager.getRemainingCooldown(player.getUniqueId());
            player.sendMessage(ChatColor.YELLOW + "⚡ Tempest Core is on cooldown! "
                    + ChatColor.WHITE + (remaining / 1000) + "s remaining.");
            return;
        }

        // All checks passed — trigger the ability!
        event.setCancelled(true);
        player.sendMessage(ChatColor.DARK_PURPLE + "⚡ " + ChatColor.WHITE + "Tempest Core activated!");
        manager.triggerAbility(player);
    }
}
