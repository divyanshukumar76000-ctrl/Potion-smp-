package com.tempestcore.ability;

import com.tempestcore.TempestCorePlugin;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

public class AbilityManager {

    private final TempestCorePlugin plugin;
    private final NamespacedKey abilityKey;

    // State tracking maps
    private final Set<UUID> activeAbility = new HashSet<>();
    private final Map<UUID, Map<UUID, Location>> frozenEntities = new HashMap<>(); // casterUUID -> (enemyUUID -> loc)
    private final Set<UUID> pearlLockActive = new HashSet<>();
    private final Map<UUID, List<BukkitTask>> taskRegistry = new HashMap<>();
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Map<UUID, boolean[]> snapshotMap = new HashMap<>(); // [0]=storm, [1]=thunder

    // For true damage bypass: track which entities are being impact-damaged
    private final Set<UUID> impactDamageTargets = new HashSet<>();
    // For fall damage: track caster UUIDs that should receive no fall damage
    // (already handled via activeAbility check in DamageListener)

    public AbilityManager(TempestCorePlugin plugin, NamespacedKey abilityKey) {
        this.plugin = plugin;
        this.abilityKey = abilityKey;
    }

    // =========================================================
    //  PUBLIC ACCESSORS
    // =========================================================

    public Set<UUID> getActiveAbility() {
        return activeAbility;
    }

    public Map<UUID, Map<UUID, Location>> getFrozenEntities() {
        return frozenEntities;
    }

    public Set<UUID> getPearlLockActive() {
        return pearlLockActive;
    }

    public Set<UUID> getImpactDamageTargets() {
        return impactDamageTargets;
    }

    public boolean isOnCooldown(UUID uuid) {
        if (!cooldowns.containsKey(uuid)) return false;
        return System.currentTimeMillis() - cooldowns.get(uuid) < 30_000L;
    }

    public long getRemainingCooldown(UUID uuid) {
        if (!cooldowns.containsKey(uuid)) return 0L;
        long remaining = 30_000L - (System.currentTimeMillis() - cooldowns.get(uuid));
        return Math.max(0L, remaining);
    }

    public NamespacedKey getAbilityKey() {
        return abilityKey;
    }

    // =========================================================
    //  ITEM CREATION
    // =========================================================

    public ItemStack createAbilityItem() {
        ItemStack item = new ItemStack(Material.PURPLE_DYE);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "⚡ Tempest Core");
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "Shift + Right Click to unleash the storm.");
        lore.add(ChatColor.DARK_PURPLE + "Phase I: " + ChatColor.WHITE + "Lock-In");
        lore.add(ChatColor.DARK_PURPLE + "Phase II: " + ChatColor.WHITE + "Ascent");
        lore.add(ChatColor.DARK_PURPLE + "Phase III: " + ChatColor.WHITE + "Gravity Drop");
        meta.setLore(lore);
        meta.getPersistentDataContainer().set(abilityKey, PersistentDataType.STRING, TempestCorePlugin.ABILITY_ID_VALUE);
        item.setItemMeta(meta);
        return item;
    }

    // =========================================================
    //  TRIGGER ENTRY POINT
    // =========================================================

    public void triggerAbility(Player caster) {
        UUID casterUUID = caster.getUniqueId();
        World world = caster.getWorld();

        // --- PRE-ABILITY SNAPSHOT ---
        boolean previousStorm = world.hasStorm();
        boolean previousThunder = world.isThundering();
        snapshotMap.put(casterUUID, new boolean[]{previousStorm, previousThunder});

        // Mark active and record cooldown
        activeAbility.add(casterUUID);
        cooldowns.put(casterUUID, System.currentTimeMillis());

        // Initialize task list for this caster
        taskRegistry.put(casterUUID, new ArrayList<>());

        // --- PHASE 1: LOCK-IN ---
        phaseLockIn(caster, world);

        // --- PHASE 2: ASCENT (delayed 10 ticks) ---
        phaseAscent(caster);

        // --- PHASE 3: GRAVITY DROP (starts at tick 70) ---
        phaseGravityDrop(caster);

        // --- HARD TIMEOUT SAFETY NET (200 ticks = 10 seconds) ---
        BukkitTask timeoutTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (activeAbility.contains(casterUUID)) {
                plugin.getLogger().warning("[TempestCore] Hard timeout triggered for " + caster.getName() + ". Forcing cleanup.");
                fullCleanup(casterUUID);
            }
        }, 200L);
        registerTask(casterUUID, timeoutTask);
    }

    // =========================================================
    //  PHASE 1 — LOCK-IN
    // =========================================================

    private void phaseLockIn(Player caster, World world) {
        UUID casterUUID = caster.getUniqueId();

        // Set thunderstorm weather
        world.setStorm(true);
        world.setThunder(true);

        // Scan 6-block radius for hostile entities
        frozenEntities.put(casterUUID, new HashMap<>());

        Collection<Entity> nearby = world.getNearbyEntities(caster.getLocation(), 6, 6, 6);
        for (Entity entity : nearby) {
            if (!(entity instanceof LivingEntity)) continue;
            if (entity.getUniqueId().equals(casterUUID)) continue;
            if (!(entity instanceof Monster) && !(entity instanceof Player)) continue;
            // Skip players who are in activeAbility (allied casters) — optional safety
            LivingEntity enemy = (LivingEntity) entity;
            UUID enemyUUID = enemy.getUniqueId();

            // Freeze the enemy
            frozenEntities.get(casterUUID).put(enemyUUID, enemy.getLocation().clone());
            pearlLockActive.add(enemyUUID);

            // Apply debuffs
            enemy.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 200, 254, false, false, false));
            enemy.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, 200, 254, false, false, false));

            // Spawn freeze particles around enemy every 2 ticks
            BukkitTask freezeParticleTask = new BukkitRunnable() {
                @Override
                public void run() {
                    if (!frozenEntities.containsKey(casterUUID) ||
                            !frozenEntities.get(casterUUID).containsKey(enemyUUID)) {
                        cancel();
                        return;
                    }
                    Location eLoc = enemy.getLocation().add(0, 1, 0);
                    // SNOWFLAKE particles
                    world.spawnParticle(Particle.SNOWFLAKE, eLoc, 8, 0.4, 0.6, 0.4, 0.01);
                    // ITEM particles (ICE block)
                    ItemStack iceItem = new ItemStack(Material.ICE);
                    world.spawnParticle(Particle.ITEM, eLoc, 5, 0.3, 0.5, 0.3, 0.05, iceItem);
                }
            }.runTaskTimer(plugin, 0L, 2L);
            registerTask(casterUUID, freezeParticleTask);
        }
    }

    // =========================================================
    //  PHASE 2 — ASCENT
    // =========================================================

    private void phaseAscent(Player caster) {
        UUID casterUUID = caster.getUniqueId();
        World world = caster.getWorld();

        // Apply Levitation after 10 ticks
        BukkitTask levitationTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!activeAbility.contains(casterUUID)) return;
            caster.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, 60, 0, false, false, false));
        }, 10L);
        registerTask(casterUUID, levitationTask);

        // Helix particle task every 2 ticks during ascent (10 to 70 ticks)
        final int[] tickCount = {0};
        final double[] angle = {0};

        BukkitTask helixTask = new BukkitRunnable() {
            @Override
            public void run() {
                if (!activeAbility.contains(casterUUID)) {
                    cancel();
                    return;
                }
                tickCount[0]++;
                if (tickCount[0] > 30) { // 30 * 2 ticks = 60 ticks of ascent
                    cancel();
                    return;
                }

                Location center = caster.getLocation().add(0, 1, 0);
                angle[0] += 15;

                // Outer helix: DRAGON_BREATH, 8 points, radius 1.2
                for (int i = 0; i < 8; i++) {
                    double a = angle[0] + (i * 45.0);
                    double x = 1.2 * Math.cos(Math.toRadians(a));
                    double z = 1.2 * Math.sin(Math.toRadians(a));
                    world.spawnParticle(Particle.DRAGON_BREATH,
                            center.clone().add(x, 0, z), 1, 0, 0, 0, 0);
                }

                // Inner helix: SOUL_FIRE_FLAME, 4 points, radius 0.6
                for (int i = 0; i < 4; i++) {
                    double a = angle[0] + (i * 90.0);
                    double x = 0.6 * Math.cos(Math.toRadians(a));
                    double z = 0.6 * Math.sin(Math.toRadians(a));
                    world.spawnParticle(Particle.SOUL_FIRE_FLAME,
                            center.clone().add(x, 0, z), 1, 0, 0, 0, 0);
                }

                // END_ROD above caster: floating upward y +1 to +2
                Location above = caster.getLocation().add(0, 1 + Math.random(), 0);
                world.spawnParticle(Particle.END_ROD, above, 3, 0.3, 0.5, 0.3, 0.02);

                // ENCHANT particles scattered in 1.5 block radius
                world.spawnParticle(Particle.ENCHANT,
                        caster.getLocation().add(0, 1, 0), 5, 1.5, 1.5, 1.5, 0.1);
            }
        }.runTaskTimer(plugin, 10L, 2L);
        registerTask(casterUUID, helixTask);
    }

    // =========================================================
    //  PHASE 3 — GRAVITY DROP
    // =========================================================

    private void phaseGravityDrop(Player caster) {
        UUID casterUUID = caster.getUniqueId();

        // Remove levitation at tick 70
        BukkitTask removeLevTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!activeAbility.contains(casterUUID)) return;
            caster.removePotionEffect(PotionEffectType.LEVITATION);
        }, 70L);
        registerTask(casterUUID, removeLevTask);

        // Ground detection starts at tick 70, checking every tick
        BukkitTask groundDetectTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!activeAbility.contains(casterUUID)) return;

            BukkitTask[] selfRef = new BukkitTask[1];
            BukkitTask detectionLoop = new BukkitRunnable() {
                @Override
                public void run() {
                    if (!activeAbility.contains(casterUUID)) {
                        cancel();
                        return;
                    }

                    Location loc = caster.getLocation();
                    // Server-side block below feet check
                    Block blockBelow = loc.getWorld().getBlockAt(
                            loc.getBlockX(),
                            loc.getBlockY() - 1,
                            loc.getBlockZ()
                    );

                    Material mat = blockBelow.getType();
                    if (mat != Material.AIR && mat != Material.VOID_AIR && mat != Material.CAVE_AIR) {
                        cancel();
                        triggerImpact(caster);
                    }
                }
            }.runTaskTimer(plugin, 0L, 1L);
            registerTask(casterUUID, detectionLoop);
        }, 70L);
        registerTask(casterUUID, groundDetectTask);
    }

    // =========================================================
    //  IMPACT SEQUENCE
    // =========================================================

    private void triggerImpact(Player caster) {
        UUID casterUUID = caster.getUniqueId();
        // Guard: prevent double-trigger if cleanup already ran
        if (!activeAbility.contains(casterUUID)) return;
        World world = caster.getWorld();
        Location impactLoc = caster.getLocation().clone();

        // 1. Strike lightning effect (no damage)
        world.strikeLightningEffect(impactLoc);

        // 2. Spawn impact particles
        // EXPLOSION_EMITTER: 1 particle
        world.spawnParticle(Particle.EXPLOSION_EMITTER, impactLoc, 1, 0, 0, 0, 0);

        // SWEEP_ATTACK: 12 particles in expanding ring
        for (int i = 0; i < 12; i++) {
            double a = (i / 12.0) * 360.0;
            double radius = 0.3 * i; // expands from 0 to ~4
            double x = radius * Math.cos(Math.toRadians(a));
            double z = radius * Math.sin(Math.toRadians(a));
            world.spawnParticle(Particle.SWEEP_ATTACK,
                    impactLoc.clone().add(x, 0.1, z), 1, 0, 0, 0, 0);
        }

        // CLOUD: 20 particles low height spread in 3 block radius
        world.spawnParticle(Particle.CLOUD, impactLoc.clone().add(0, 0.3, 0),
                20, 3.0, 0.2, 3.0, 0.01);

        // ELECTRIC_SPARK: scatter 30 particles for 3 ticks
        BukkitTask sparkTask = new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks >= 3) {
                    cancel();
                    return;
                }
                world.spawnParticle(Particle.ELECTRIC_SPARK,
                        impactLoc.clone().add(0, 0.5, 0), 30, 2.0, 0.5, 2.0, 0.1);
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        // Don't register — this runs independently after cleanup
        // NOTE: intentionally unregistered - runs for only 3 ticks post-impact, safe

        // 3. Damage and knockback all frozen enemies
        Map<UUID, Location> frozen = frozenEntities.getOrDefault(casterUUID, Collections.emptyMap());
        for (Map.Entry<UUID, Location> entry : new HashMap<>(frozen).entrySet()) {
            UUID enemyUUID = entry.getKey();
            Entity entity = Bukkit.getEntity(enemyUUID);
            if (!(entity instanceof LivingEntity)) continue;
            LivingEntity enemy = (LivingEntity) entity;

            // True damage: mark then call damage(10)
            impactDamageTargets.add(enemyUUID);
            enemy.damage(10.0, caster);

            // Knockback: direction from caster to enemy, normalized * 1.5, +y 0.4
            Vector dir = enemy.getLocation().toVector()
                    .subtract(impactLoc.toVector());
            if (dir.lengthSquared() > 0) {
                dir.normalize().multiply(1.5);
            } else {
                dir = new Vector(0, 0, 0);
            }
            dir.setY(0.4);
            enemy.setVelocity(dir);
        }

        // 4. Full cleanup
        fullCleanup(casterUUID);

        // Cancel spark task after cleanup (it references local scope, fine)
        Bukkit.getScheduler().runTaskLater(plugin, sparkTask::cancel, 5L);
    }

    // =========================================================
    //  FULL CLEANUP
    // =========================================================

    public void fullCleanup(UUID casterUUID) {
        // 1. Remove from active set
        activeAbility.remove(casterUUID);

        // 2. Unfreeze all enemies for this caster
        Map<UUID, Location> frozen = frozenEntities.remove(casterUUID);
        if (frozen != null) {
            for (UUID enemyUUID : frozen.keySet()) {
                Entity entity = Bukkit.getEntity(enemyUUID);
                if (entity instanceof LivingEntity enemy) {
                    enemy.removePotionEffect(PotionEffectType.SLOWNESS);
                    enemy.removePotionEffect(PotionEffectType.MINING_FATIGUE);
                }
                pearlLockActive.remove(enemyUUID);
            }
        }

        // 3. Cancel and clear all tasks for this caster
        List<BukkitTask> tasks = taskRegistry.remove(casterUUID);
        if (tasks != null) {
            for (BukkitTask task : tasks) {
                try {
                    task.cancel();
                } catch (Exception ignored) {}
            }
        }

        // 4. Restore weather from snapshot
        boolean[] snapshot = snapshotMap.remove(casterUUID);
        Player caster = Bukkit.getPlayer(casterUUID);
        if (caster != null && caster.isOnline()) {
            World world = caster.getWorld();
            if (snapshot != null) {
                world.setStorm(snapshot[0]);
                world.setThunder(snapshot[1]);
            } else {
                world.setStorm(false);
                world.setThunder(false);
            }
        }
        // Note: cooldown entry is intentionally NOT removed here
    }

    // =========================================================
    //  HELPER: remove a single frozen entity from all maps
    //  (used when frozen enemy dies, without full cleanup)
    // =========================================================

    public void removeFrozenEnemy(UUID enemyUUID) {
        pearlLockActive.remove(enemyUUID);
        impactDamageTargets.remove(enemyUUID);
        // Remove from whichever caster's frozen map this enemy belongs to
        for (Map<UUID, Location> map : frozenEntities.values()) {
            map.remove(enemyUUID);
        }
        // Remove debuffs
        Entity entity = Bukkit.getEntity(enemyUUID);
        if (entity instanceof LivingEntity enemy) {
            enemy.removePotionEffect(PotionEffectType.SLOWNESS);
            enemy.removePotionEffect(PotionEffectType.MINING_FATIGUE);
        }
    }

    // =========================================================
    //  HELPER: register a task to a caster's task list
    // =========================================================

    public void registerTask(UUID casterUUID, BukkitTask task) {
        taskRegistry.computeIfAbsent(casterUUID, k -> new ArrayList<>()).add(task);
    }

    // =========================================================
    //  GROUND CHECK (server-side)
    // =========================================================

    public boolean isOnGround(Player player) {
        Location loc = player.getLocation();
        Block blockBelow = loc.getWorld().getBlockAt(
                loc.getBlockX(),
                loc.getBlockY() - 1,
                loc.getBlockZ()
        );
        Material mat = blockBelow.getType();
        return mat != Material.AIR && mat != Material.VOID_AIR && mat != Material.CAVE_AIR;
    }
}
