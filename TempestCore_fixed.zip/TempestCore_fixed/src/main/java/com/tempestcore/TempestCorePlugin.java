package com.tempestcore;

import com.tempestcore.ability.AbilityManager;
import com.tempestcore.commands.TempestCoreCommand;
import com.tempestcore.listeners.*;
import org.bukkit.NamespacedKey;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class TempestCorePlugin extends JavaPlugin {

    public static final String ABILITY_ID_VALUE = "tempest_core";

    private NamespacedKey abilityKey;
    private AbilityManager abilityManager;

    @Override
    public void onEnable() {
        // Register the NamespacedKey
        this.abilityKey = new NamespacedKey(this, "ability_id");

        // Create the ability manager
        this.abilityManager = new AbilityManager(this, abilityKey);

        // Register all event listeners
        getServer().getPluginManager().registerEvents(new PlayerInteractListener(abilityManager, abilityKey), this);
        getServer().getPluginManager().registerEvents(new PlayerMoveListener(abilityManager), this);
        getServer().getPluginManager().registerEvents(new TeleportListener(abilityManager), this);
        getServer().getPluginManager().registerEvents(new DamageListener(abilityManager), this);
        getServer().getPluginManager().registerEvents(new PlayerStateListener(abilityManager), this);

        // Register commands
        TempestCoreCommand cmd = new TempestCoreCommand(this, abilityKey);
        getCommand("tempestcore").setExecutor(cmd);
        getCommand("tempestcore").setTabCompleter(cmd);

        getLogger().info("TempestCore enabled! NamespacedKey registered: " + abilityKey);
    }

    @Override
    public void onDisable() {
        // Safety net: clean up all active abilities on disable/reload
        if (abilityManager != null) {
            Set<UUID> active = new HashSet<>(abilityManager.getActiveAbility());
            for (UUID uuid : active) {
                abilityManager.fullCleanup(uuid);
            }
        }
        getLogger().info("TempestCore disabled. All active abilities cleaned up.");
    }

    public NamespacedKey getAbilityKey() {
        return abilityKey;
    }

    public AbilityManager getAbilityManager() {
        return abilityManager;
    }
}
