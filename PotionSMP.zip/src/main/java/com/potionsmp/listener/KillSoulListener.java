package com.potionsmp.listener;

public class KillSoulListener {
}
