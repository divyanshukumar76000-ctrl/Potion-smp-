package com.potionsmp.listener;

public class AbilityCastListener {
}
