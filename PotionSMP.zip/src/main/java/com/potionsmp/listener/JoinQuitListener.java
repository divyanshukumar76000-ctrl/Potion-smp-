package com.potionsmp.listener;

public class JoinQuitListener {
}
