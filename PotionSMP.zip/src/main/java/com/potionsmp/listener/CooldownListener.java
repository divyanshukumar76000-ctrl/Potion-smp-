package com.potionsmp.listener;

public class CooldownListener {
}
