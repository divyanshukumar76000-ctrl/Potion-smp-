package com.potionsmp.listener;

public class CombatListener {
}
