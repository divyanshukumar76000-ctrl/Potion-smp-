package com.potionsmp.util;

public class NamespacedKeyUtil {
}
