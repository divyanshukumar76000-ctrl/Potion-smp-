
package com.potionsmp;

import org.bukkit.plugin.java.JavaPlugin;

public class ChaosPlugin extends JavaPlugin {
    @Override
    public void onEnable() {
        getLogger().info("Potion SMP enabled");
    }
}
