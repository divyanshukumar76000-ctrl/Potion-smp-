package com.potionsmp.manager;

public class PotionManager {
}
