package com.potionsmp.manager;

public class StateManager {
}
