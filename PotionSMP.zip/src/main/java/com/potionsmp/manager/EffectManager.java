package com.potionsmp.manager;

public class EffectManager {
}
