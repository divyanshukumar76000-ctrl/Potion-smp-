package com.potionsmp.manager;

public class CooldownManager {
}
